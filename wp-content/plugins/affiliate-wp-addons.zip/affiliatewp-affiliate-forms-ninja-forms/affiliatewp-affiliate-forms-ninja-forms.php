<?php
/**
 * Plugin Name: AffiliateWP - Affiliate Forms For Ninja Forms
 * Plugin URI: https://affiliatewp.com/add-ons/pro/affiliate-forms-for-ninja-forms/
 * Description: Create an affiliate registration form using Ninja Forms
 * Author: Sandhills Development, LLC
 * Author URI: https://sandhillsdev.com
 * Version: 1.2.1
 * Text Domain: affiliatewp-afnf
 * Domain Path: languages
 *
 * AffiliateWP is distributed under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * AffiliateWP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AffiliateWP. If not, see <http://www.gnu.org/licenses/>.
 *
 * @package AffiliateWP Affiliate Forms For Ninja Forms
 * @category Core
 * @author Sandhills Development, LLC
 * @version 1.2.1
 */

if ( ! class_exists( 'AffiliateWP_Requirements_Check_v1_1' ) ) {
	require_once dirname( __FILE__ ) . '/includes/lib/affwp/class-affiliatewp-requirements-check-v1-1.php';
}

/**
 * Class used to check requirements for and bootstrap the plugin.
 *
 * @since 1.2
 *
 * @see Affiliate_WP_Requirements_Check
 */
class AffiliateWP_AFNF_Requirements_Check extends AffiliateWP_Requirements_Check_v1_1 {

	/**
	 * Plugin slug.
	 *
	 * @since 1.2
	 * @var   string
	 */
	protected $slug = 'affiliatewp-affiliate-forms-ninja-forms';

	/**
	 * Add-on requirements.
	 *
	 * @since 1.2
	 * @var   array[]
	 */
	protected $addon_requirements = array(
		// AffiliateWP.
		'affwp' => array(
			'minimum' => '2.6',
			'name'    => 'AffiliateWP',
			'exists'  => true,
			'current' => false,
			'checked' => false,
			'met'     => false,
		),

		// Ninja Forms
		'nf' => array(
			'minimum' => '2.0.0',
			'name'    => 'Ninja Forms',
			'exists'  => true,
			'current' => false,
			'checked' => false,
			'met'     => false,
		),
	);

	/**
	 * Bootstrap everything.
	 *
	 * @since 1.2
	 */
	public function bootstrap() {
		\AffiliateWP_Affiliate_Forms_For_Ninja_Forms::instance( __FILE__ );
	}

	/**
	 * Loads the AFNF add-on if requirements are truly met and activated.
	 *
	 * At this point in the loading order, the requirements class has confirmed all dependency
	 * versions are aligned with the minimum requirements, but plugins_loaded has not yet fired.
	 *
	 * Because this is happening so early (due to constraints with how NF3 bootstraps), class_exists()
	 * or other more traditional methods can't be reliably used, so we instead check to see if either
	 * or both AffiliateWP and Ninja Forms are actually installed and activated.
	 *
	 * The main plugin bootstrap, if allowed to fire, is hooked to ninja_forms_loaded.
	 *
	 * @since 1.2
	 */
	protected function load() {

		$requirements_met = true;

		if ( is_admin() ) {
			if ( ! function_exists( 'get_plugins' ) ) {
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
			}

			$plugins_keys = array_keys( get_plugins() );

			$found   = preg_grep( '/\/ninja-forms.php$/', $plugins_keys );
			$nf_path = empty( $found ) ? '' : reset( $found );

			/*
			 * Handle the missing Ninja Forms admin notice if needed.
			 *
			 * is_plugin_active() is used instead of class_exists( 'Ninja_Forms' ) because
			 * NF3 bootstraps on plugins_loaded, though it evaluates several filters prior.
			 * At this point in the loading order, the Ninja_Forms class does not yet "exist,"
			 * even if Ninja Forms is technically activated.
			 */
			if ( ! is_plugin_active( $nf_path ) ) {
				$requirements_met = false;

				if ( ! class_exists( 'AffiliateWP_Affiliate_Forms_For_Ninja_Forms_Activation' ) ) {
					require_once plugin_dir_path( __FILE__ ) . '/includes/class-activation-ninja-forms.php';
				}

				$activation = new AffiliateWP_Affiliate_Forms_For_Ninja_Forms_Activation( plugin_dir_path( __FILE__ ), basename( __FILE__ ) );
				$activation = $activation->run();
			}

			$found      = preg_grep( '/\/affiliate-wp.php$/', $plugins_keys );
			$affwp_path = empty( $found ) ? '' : reset( $found );

			// Handle the missing AffiliateWP admin notice if needed.
			if ( ! is_plugin_active( $affwp_path ) ) {
				$requirements_met = false;

				$this->trigger_affiliatewp_activation_notice();
			}
		}

		if ( true === $requirements_met ) {
			// Preload code needed for NF3.
			require_once dirname( __FILE__ ) . '/includes/preload.php';

			// Maybe include the bundled bootstrapper.
			if ( ! class_exists( 'AffiliateWP_Affiliate_Forms_For_Ninja_Forms' ) ) {
				require_once dirname( __FILE__ ) . '/includes/class-affiliatewp-affiliate-forms-ninja-forms.php';
			}

			// Bootstrap the add-on.
			add_action( 'ninja_forms_loaded', array( $this, 'bootstrap' ) );
		}
	}

	/**
	 * Triggers initiating the AffiliateWP activation notice.
	 *
	 * @since 1.2
	 *
	 * @see \AffiliateWP_Activation
	 */
	public function trigger_affiliatewp_activation_notice() {
		if ( ! class_exists( 'AffiliateWP_Activation' ) ) {
			require_once plugin_dir_path( __FILE__ ) . 'includes/lib/affwp/class-affiliatewp-activation.php';
		}

		$activation = new AffiliateWP_Activation( plugin_dir_path( __FILE__ ), basename( __FILE__ ) );
		$activation = $activation->run();
	}

	/**
	 * Install, usually on an activation hook.
	 *
	 * @since 1.2
	 */
	public function install() {
		// Bootstrap to include all of the necessary files
		$this->bootstrap();

		if ( defined( 'AFFWP_AFNF_VERSION' ) ) {
			update_option( 'affwp_afnf_version', AFFWP_AFNF_VERSION );
		}
	}

	/**
	 * Plugin-specific aria label text to describe the requirements link.
	 *
	 * @since 1.2
	 *
	 * @return string Aria label text.
	 */
	protected function unmet_requirements_label() {
		return esc_html__( 'AffiliateWP - Affiliate Forms for Ninja Forms Requirements', 'affiliatewp-afnf' );
	}

	/**
	 * Plugin-specific text used in CSS to identify attribute IDs and classes.
	 *
	 * @since 1.2
	 *
	 * @return string CSS selector.
	 */
	protected function unmet_requirements_name() {
		return 'affiliatewp-afnf-requirements';
	}

	/**
	 * Plugin specific URL for an external requirements page.
	 *
	 * @since 1.0.0
	 *
	 * @return string Unmet requirements URL.
	 */
	protected function unmet_requirements_url() {
		return 'https://docs.affiliatewp.com/article/2361-minimum-requirements-roadmaps';
	}

	/**
	 * Retrieves the Ninja Forms version.
	 *
	 * @since 1.2
	 */
	public function check_nf() {
		return get_option( 'ninja_forms_version' );
	}

}

$requirements = new AffiliateWP_AFNF_Requirements_Check( __FILE__ );

$requirements->maybe_load();
