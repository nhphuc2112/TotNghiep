<?php
/**
 * Bootstrap: Preload
 *
 * Sets up Ninja Forms logic that has to be registered to hook callbacks
 * before the main bootstrap is fired on the 'ninja_forms_loaded' action.
 *
 * @package     AffiliateWP Affiliate Forms Ninja Forms
 * @subpackage  Bootstrap
 * @copyright   Copyright (c) 2021, Sandhills Development, LLC
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.2
 */

/**
 * Registers Ninja Forms 3 fields.
 *
 * @since 1.1 as AffiliateWP_Affiliate_Forms_Ninja_Forms::register_fields()
 * @since 1.2 Moved and converted to initialize outside the bootstrap.
 *
 * @param array $actions An array of fields to register.
 * @return array $actions An array of Ninja Forms 3 fields.
 */
function affwp_afnf_register_fields( $actions ) {
	// Field types
	require_once dirname( __FILE__ ) . '/fields/class-affiliate-username.php';
	require_once dirname( __FILE__ ) . '/fields/class-website-url.php';
	require_once dirname( __FILE__ ) . '/fields/class-promotion-method.php';
	require_once dirname( __FILE__ ) . '/fields/class-payment-email.php';

	$actions[ 'affwp_afnf_username' ]         = new AFNF_Affiliate_Username();
	$actions[ 'affwp_afnf_payment_email' ]    = new AFNF_Payment_Email();
	$actions[ 'affwp_afnf_promotion_method' ] = new AFNF_Promotion_Method();
	$actions[ 'affwp_afnf_website_url' ]      = new AFNF_Website_URL();

	return $actions;
}
add_filter( 'ninja_forms_register_fields', 'affwp_afnf_register_fields' );

/**
 * Registers the Ninja Forms 3 affiliate registration action.
 *
 * @since 1.1 as AffiliateWP_Affiliate_Forms_Ninja_Forms::register_actions()
 * @since 1.2 Moved and converted to initialize outside the bootstrap.
 *
 * @param  array  $actions Ninja Forms form admin actions
 *
 * @return array           Ninja Forms form actions
 */
function affwp_afnf_register_actions( $actions ) {
	// Registration
	require_once dirname( __FILE__ ) . '/class-register.php';

	$actions[ 'affwp_afnf_register' ] = new AffiliateWP_AFNF_Register();

	return $actions;
}
add_filter( 'ninja_forms_register_actions', 'affwp_afnf_register_actions' );
