<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

class AffiliateWP_PayPal_Payouts_Admin {

	/**
	 * Get things started
	 *
	 * @since 1.0
	 * @return void
	 */
	public function __construct() {

		$version = get_option( 'affwp_version' );

		// Keeps compatibility with older versions of AffiliateWP.
		if ( version_compare( $version, '2.18.0', '<' ) ) {

			add_filter( 'affwp_settings_tabs', array( $this, 'setting_tab' ) );
			add_filter( 'affwp_settings', array( $this, 'register_settings_legacy' ) );

			return;
		}

		// Use the new section system.
		add_filter( 'affwp_settings_commissions', array( $this, 'register_settings' ) );
		add_action( 'affiliatewp_after_register_admin_sections', array( $this, 'register_section' ) );
	}

	/**
	 * Register the new settings tab
	 *
	 * @since 1.0
	 *
	 * @param array $tabs The array of tabs.
	 *
	 * @return array
	 */
	public function setting_tab( array $tabs ) : array {
		$tabs['paypal'] = __( 'PayPal Payouts', 'affwp-paypal-payouts' );
		return $tabs;
	}

	/**
	 * Return the list of settings.
	 *
	 * @since 1.4.1
	 * @return array
	 */
	private function get_settings() : array {

		return array(
			'paypal_payout_mode' => array(
				'name' => __( 'Payout API to Use', 'affwp-paypal-payouts' ),
				'desc' => __( 'Select the payout method you wish to use. PayPal MassPay is an older technology not available to all accounts. See <a href="https://affiliatewp.com/docs/paypal-payouts-installation-and-usage/" target="_blank" rel="noopener noreferrer">documentation</a> for assistance.', 'affwp-paypal-payouts' ),
				'type' => 'select',
				'options' => array(
					'api'     => __( 'API Application', 'affwp-paypal-payouts' ),
					'masspay' => __( 'MassPay', 'affwp-paypal-payouts' )
				)
			),
			'paypal_test_mode' => array(
				'name' => __( 'Test Mode', 'affwp-paypal-payouts' ),
				'desc' => __( 'Check this box if you would like to use PayPal Payouts in Test Mode', 'affwp-paypal-payouts' ),
				'type' => 'checkbox'
			),
			'paypal_api_header' => array(
				'name' => __( 'PayPal API Application Credentials', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your PayPal API Application credentials.', 'affwp-paypal-payouts' ),
				'type' => 'header'
			),
			'paypal_live_client_id' => array(
				'name' => __( 'Client ID', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your PayPal Application\'s Client ID. Create or retrieve these from <a href="https://developer.paypal.com/developer/applications/" target="_blank">PayPal\'s Developer portal</a>.', 'affwp-paypal-payouts' ),
				'type' => 'text'
			),
			'paypal_live_secret' => array(
				'name' => __( 'Secret', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your PayPal Application\'s Secret.', 'affwp-paypal-payouts' ),
				'type' => 'text'
			),
			'paypal_test_client_id' => array(
				'name' => __( 'Test Client ID', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your Sandbox PayPal Application\'s Client ID.', 'affwp-paypal-payouts' ),
				'type' => 'text'
			),
			'paypal_test_secret' => array(
				'name' => __( 'Test Secret', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your Sandbox PayPal Application\'s Secret.', 'affwp-paypal-payouts' ),
				'type' => 'text'
			),
			'paypal_masspay_header' => array(
				'name' => __( 'PayPal MassPay Credentials', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your Test API Username.', 'affwp-paypal-payouts' ),
				'type' => 'header'
			),
			'paypal_test_username' => array(
				'name' => __( 'Test API Username', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your Test API Username.', 'affwp-paypal-payouts' ),
				'type' => 'text'
			),
			'paypal_test_password' => array(
				'name' => __( 'Test API Password', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your Test API Password.', 'affwp-paypal-payouts' ),
				'type' => 'text'
			),
			'paypal_test_signature' => array(
				'name' => __( 'Test API Signature', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your Test API Signature.', 'affwp-paypal-payouts' ),
				'type' => 'text'
			),
			'paypal_live_username' => array(
				'name' => __( 'Live API Username', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your Live API Username.', 'affwp-paypal-payouts' ),
				'type' => 'text'
			),
			'paypal_live_password' => array(
				'name' => __( 'Live API Password', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your Live API Password.', 'affwp-paypal-payouts' ),
				'type' => 'text'
			),
			'paypal_live_signature' => array(
				'name' => __( 'Live API Signature', 'affwp-paypal-payouts' ),
				'desc' => __( 'Enter your Live API Signature.', 'affwp-paypal-payouts' ),
				'type' => 'text'
			)
		);
	}

	/**
	 * Register the settings for our PayPal Payouts tab.
	 *
	 * @since 1.0
	 *
	 * @param array $settings The array of settings.
	 *
	 * @return array
	 */
	public function register_settings( array $settings ) : array {

		return array_merge_recursive(
			$settings,
			$this->get_settings()
		);
	}

	/**
	 * Register the settings for our PayPal Payouts tab for older AffiliateWP versions.
	 *
	 * @since 1.0
	 *
	 * @since 1.4.1 It know uses the get_settings() method to get all settings.
	 *
	 * @param array $settings The array of settings.
	 *
	 * @return array
	 */
	public function register_settings_legacy( array $settings ) : array {

		$settings['paypal'] = $this->get_settings();

		return $settings;
	}

	/**
	 * Register the settings section.
	 *
	 * @since 1.4.1
	 */
	public function register_section() {

		if ( ! method_exists( affiliate_wp()->settings, 'register_section' ) ) {
			return; // It is an old AffiliateWP and do not have support for sections.
		}

		affiliate_wp()->settings->register_section(
			'commissions',
			'paypal_payouts',
			__( 'PayPal Payouts Payment Method', 'affiliate-wp' ),
			apply_filters(
				'affiliatewp_register_section_paypal_payouts',
				array(
					'paypal_payout_mode',
					'paypal_test_mode',
					'paypal_api_header',
					'paypal_live_client_id',
					'paypal_live_secret',
					'paypal_test_client_id',
					'paypal_test_secret',
					'paypal_masspay_header',
					'paypal_test_username',
					'paypal_test_password',
					'paypal_test_signature',
					'paypal_live_username',
					'paypal_live_password',
					'paypal_live_signature',
				)
			),
			'',
			array(
				'required_field' => 'paypal_payouts',
				'value'          => true
			),
		);
	}
}
new AffiliateWP_PayPal_Payouts_Admin();
