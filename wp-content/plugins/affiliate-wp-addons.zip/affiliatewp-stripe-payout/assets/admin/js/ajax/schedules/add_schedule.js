(function($, w) {
    'use strict';

    if ($('#awp_sp_add_schedule_affilities_include_exclude').length > 0) {

        $('select').DualListBox({
            // defaults
            element: $(this).context,
            available: {
                ajax: {
                    url: add_schedule_get_all_affiliates.ajax.url,
                    method: 'POST',
                    data: {
                        action: 'add_schedule_get_all_affiliates',
                        security: add_schedule_get_all_affiliates.ajax.nonce,
                    },
                },
                ui: {
                    title: 'Included Affiliates',
                },
                search: {
                    placeholder: 'Search Affiliates'
                }
            },
            selected: {
                ajax: {
                    url: '',
                    method: 'POST',
                    data: {
                        action: '',
                        security: '',
                    },
                },
                ui: {
                    title: 'Excluded Affiliates',
                },
                search: {
                    placeholder: 'Search Affiliates'
                }
            },
            parent_id: 'awp_sp_add_schedule_affilities_include_exclude',
            value: 'user_id',
            text: 'user_name',
            // json: true,
            timeout: 500,
            horizontal: false,
            textLength: 45,
            moveAllBtn: true,
            maxAllBtn: 500,
            selectClass: 'form-control',
            warning: 'Are you sure you want to move this many items? Doing so can cause your browser to become unresponsive.'
        });

    }

    /* Calculate Schedule Interval in Seconds */
    $(".awp_sp_sf_icf").on("keyup", function() {
        var sum = 0;
        $(".awp_sp_sf_icf").each(function() {
            var id = $(this).attr('id');
            var value = $(this).val();
            var seconds = 0;
            if (id == 'awp_sp_sf_seconds') {
                seconds = value;
            } else if (id == 'awp_sp_sf_minutes') {
                seconds = (value * 60);
            } else if (id == 'awp_sp_sf_hours') {
                seconds = ((value * 60) * 60);
            } else if (id == 'awp_sp_sf_days') {
                seconds = (((value * 60) * 60) * 24);
            }

            sum += +seconds;
        });
        $('#awp_sp_sf_interval').val(sum);
    });


    /* Set - First Execution Time Date & Picker */
    // var start_date_time_inpt = moment().format("YYY-MM-DD hh:mm:ss A");
    var start_date_time_inpt = $('#awp_sp_sf_fet').val();
    $('#awp_sp_sf_fet').val(start_date_time_inpt);
    $.fn.schedules_fet_date_time_picker('awp_sp_sf_fet', 'YYYY-MM-DD hh:mm:ss A', start_date_time_inpt);

    /* Start - Post Stripe Account INtegration */
    $('#awp_sp_add_schedule_form').on('submit', function(e) {
        e.preventDefault();
        $('#awp_sp_add_schedule_form').loader('show');
        // var self = $(this);
        // var loaderContainer = $('<span/>', {
        //     'class': 'loader-image-container'
        // }).insertAfter(self);
        // var loader = $('<img/>', {
        //     src: 'http://aff.localhost.com/wp-admin/images/loading.gif',
        //     'class': 'loader-image'
        // }).appendTo(loaderContainer);
        var data = {
            action: 'add_schedule',
            security: add_schedule.ajax.nonce,
            status: $('input[name="awp_sp_sf_status"]:checked').val(),
            title: $('#awp_sp_sf_title').val(),
            first_execution_time: $('#awp_sp_sf_fet').val(),
            days: $('#awp_sp_sf_days').val(),
            hours: $('#awp_sp_sf_hours').val(),
            minutes: $('#awp_sp_sf_minutes').val(),
            seconds: $('#awp_sp_sf_seconds').val(),
            interval: $('#awp_sp_sf_interval').val(),
            excluded_affiliates: $('#awp_sp_add_schedule_affilities_include_exclude').getSelected(),
        };

        // console.log("Dat = " + JSON.stringify(data));


        $.ajax({
            method: 'POST',
            url: add_schedule.ajax.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', add_schedule.ajax.nonce);
            },
            data: data
        }).then(function(r) {
            // console.log("Add Response = " + JSON.stringify(r));
            alertify.set('notifier', 'position', 'top-right');
            alertify.success(add_schedule.ajax.messages.success);
            // loaderContainer.remove();
            if (r.hasOwnProperty('data')) {
                if (r.data.hasOwnProperty('schedule_id') && r.data.schedule_id != 0) {
                    var page = $.fn.getQueryStringByName('page');
                    var tab = $.fn.getQueryStringByName('tab');
                    var edit_url = location.protocol + '//' + location.hostname + location.pathname + '?page=' + page + '&tab=' + tab + '&screen=edit-schedule&id=' + r.data.schedule_id;
                    window.location.href = edit_url;
                    // window.location.href = window.location.href + '&id=' + r.data.schedule_id;
                }
            }
            $('#awp_sp_add_schedule_form').loader('hide');
        }).fail(function(r) {
            var message = add_schedule.ajax.messages.error;
            if (r.hasOwnProperty('message')) {
                message = r.message;
            }
            alertify.set('notifier', 'position', 'top-right');
            alertify.error(add_schedule.ajax.messages.error);
        });
    });
    /* End - Post Stripe Account INtegration */

})(jQuery, window);