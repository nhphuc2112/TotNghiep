(function($, w) {
    'use strict';

    /* Start - Get Stripe Account INtegration */
    if ($('#awp_sp_account_balance_section').length > 0) {
        $('#awp_sp_admin_stripe_account_testing_balance_settings_form').loader('show');
        $.ajax({
            method: 'POST',
            url: stripe_account_balance.ajax.get.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', stripe_account_balance.ajax.get.nonce);
            },
            data: {
                action: stripe_account_balance.ajax.get.action,
                security: stripe_account_balance.ajax.get.nonce,
            },
        }).then(function(r) {
            // console.log("R = " + JSON.stringify(r));
            if (r.data.hasOwnProperty('available')) {
				// console.log('ejaz balance testing up');
				if (r.data.hasOwnProperty('available')) {
                if ( r.data.available.hasOwnProperty('is_zero_decimal_currency') && r.data.available.hasOwnProperty('amount') && r.data.available.hasOwnProperty('currency')) {
					if( 'no' == r.data.available.is_zero_decimal_currency ){
						$('#asab_amount').text(((r.data.available.amount) / 100));
					}else{
						$('#asab_amount').text(r.data.available.amount);
					}
                    $('#asab_currency').text(r.data.available.currency);
                }
            }
            }
            $('#awp_sp_admin_stripe_account_testing_balance_settings_form').loader('hide');
        });
    }
    /* End - Get Stripe Account INtegration */


    /* Start - Post Stripe Account INtegration */
    $('#awp_sp_admin_stripe_account_testing_balance_settings_form').on('submit', function(e) {
        e.preventDefault();
        $('#awp_sp_admin_stripe_account_testing_balance_settings_form').loader('show');
        var data = {
            action: stripe_account_balance.ajax.update.action,
            security: stripe_account_balance.ajax.update.nonce,
            amount: $('input[name="balance"]').val(),
        };

        $.ajax({
            method: 'POST',
            url: stripe_account_balance.ajax.update.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', stripe_account_balance.ajax.update.nonce);
            },
            data: data
        }).then(function(r) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.success(stripe_account_balance.ajax.update.messages.success);
            // loaderContainer.remove();
            $('#awp_sp_admin_stripe_account_testing_balance_settings_form').loader('hide');
            window.location.reload(true);
        }).fail(function(r) {
            var message = stripe_account_balance.ajax.update.messages.error;
            if (r.hasOwnProperty('message')) {
                message = r.message;
            }
            alertify.set('notifier', 'position', 'top-right');
            alertify.error(stripe_account_balance.ajax.update.messages.error);
        });
    });
    /* End - Post Stripe Account INtegration */

})(jQuery, window);