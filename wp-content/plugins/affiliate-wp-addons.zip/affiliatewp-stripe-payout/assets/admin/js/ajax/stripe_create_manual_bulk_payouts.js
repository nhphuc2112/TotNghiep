(function ($, w) {
    'use strict';

    /* 
     * Table Head & Footer CheckBox Validation in-bulk selection
     * Prevent selection of rows where stripe payout option not found
     * Reason 01. Referral is Already Paid
     * Reason 02. Affiliate Stripe Account is not connected 
     */
    $('thead input[type="checkbox"], tfoot input[type="checkbox"]').change(function () {
        $('input[name="referral_id[]"]:checked').each(function () {
            var action = $('select[name="action"] option:selected').val();
            var action2 = $('select[name="action2"] option:selected').val();
            if (action == 'stripe_bulk_payout' || action2 == 'stripe_bulk_payout') {
                if (this.checked && $($(this).parent().siblings('td.actions')).find('span.stripe-payout').length == 0) {
                    // console.log("ch cs 01");
                    $(this).prop('checked', false);
                }
            }
        });
    });

    /* 
     * Table Induval Row CheckBox selection validation
     * Prevent selection of rows where stripe payout option not found
     * Reason 01. Referral is Already Paid
     * Reason 02. Affiliate Stripe Account is not connected 
     */
    $('input[name="referral_id[]"]').change(function () {
        var action = $('select[name="action"] option:selected').val();
        var action2 = $('select[name="action2"] option:selected').val();
        if (action == 'stripe_bulk_payout' || action2 == 'stripe_bulk_payout') {
            if (this.checked && $($(this).parent().siblings('td.actions')).find('span.stripe-payout').length == 0) {
                // console.log("ch cs 02");
                $(this).prop('checked', false);
            }
        }
    });

    $('select[name="action"], select[name="action2"]').change(function () {
        if ($(this).val() == 'stripe_bulk_payout') {
            $('input[name="referral_id[]"]:checked').each(function () {
                if (this.checked && $($(this).parent().siblings('td.actions')).find('span.stripe-payout').length == 0) {
                    // console.log("ch cs 01");
                    $(this).prop('checked', false);
                }
            });
            /* Disabled Apply Button if noone box can be checked */
            if ($('input[name="referral_id[]"]:checked').length == 0) {
                //    $('.bulkactions #doaction, .bulkactions #doaction2').prop('disabled', 'disabled');
            }
        } else {
            /* Enable Apply Button if Stripe_Bulk_Payout Action nOt Selected from DropDown */
            //$('.bulkactions #doaction, .bulkactions #doaction2').prop('disabled', '');
        }
    });

    /* Start - Stripe Bulk Manual Payouts */
    $('.bulkactions #doaction, .bulkactions #doaction2').on('click', function (e) {
        // $('table').loader('show');
        var action = $('select[name="action"] option:selected').val();
        var action2 = $('select[name="action2"] option:selected').val();
        if (action == 'stripe_bulk_payout' || action2 == 'stripe_bulk_payout') {
            e.preventDefault();
            // console.log('that is working area!');
            $('table').loader('show');
            var referral_ids = [];
            $('input[name="referral_id[]"]:checked').each(function () {
                referral_ids.push($(this).val());
            });
            // console.log("Referral IDs = " + referral_ids);
            // var referral_ids = $('input[name="referral_id[]"]:checked').val();
            var data = {
                action: 'create_stripe_manual_bulk_payouts',
                security: stripe_create_manual_bulk_payouts.ajax.nonce,
                referrals: referral_ids
            };
            $.ajax({
                method: 'POST',
                url: stripe_create_manual_bulk_payouts.ajax.url,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', stripe_create_manual_bulk_payouts.ajax.nonce);
                },
                data: data,
            }).then(function (r) {
                /**
                 * Alertify JS Notification
                 */
                alertify.set('notifier', 'position', 'top-right');
                alertify.set('notifier', 'delay', 2);
                var notification;
                $(r.data).each(function (e) {
                    // console.log(r.data[e].status);
                    // console.log(r.data[e].detail);
                    if (r.data[e].status == 'success') {
                        notification = alertify.success(stripe_create_manual_payout.ajax.messages.success);
                    } else {
                        var html = stripe_create_manual_payout.ajax.messages.error;
                        html += "<br\> <b>Stripe Error Code:</b> " + r.data.code;
                        html += "<br\> <b>Stripe Error message:</b> " + r.data.message;
                        notification = alertify.error(html);
                    }
                });
                notification.ondismiss = function () {
                    $('table').loader('hide');
                    window.location.reload();
                };
                // $('table').loader('hide');
            }).fail(function (r) {
                var message = stripe_manual_payout.strings.error;
                if (r.hasOwnProperty('message')) {
                    message = r.message;
                }
            });
        }
    });
    /* End - Stripe Bulk Manual Payout */
})(jQuery, window);