(function($, w) {
    'use strict';

    /* Start - Get Stripe Account INtegration */
    if ($('#awp_sp_admin_stripe_account_integration_settings_form').length > 0) {
        $('#awp_sp_admin_stripe_account_integration_settings_form').loader('show');
        $.ajax({
            method: 'POST',
            url: stripe_account_integration_settings.ajax.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', stripe_account_integration_settings.ajax.nonce);
            },
            data: {
                action: 'get_stripe_account_integration_settings',
                security: stripe_account_integration_settings.ajax.nonce,
            },
        }).then(function(r) {
            // console.log("R = " + JSON.stringify(r));
            if (r.hasOwnProperty('account_id')) {
                $('#awp_sp_account_id').val(r.account_id);
            }

            if (r.hasOwnProperty('access_mode')) {
                $("input[name=access_mode][value=" + r.access_mode + "]").prop('checked', true);
                $("input[name=access_mode][value=" + r.access_mode + "]").trigger('change');
            }

            if (r.test.hasOwnProperty('pk')) {
                $('#awp_sp_test_pk').val(r.test.pk);
            }

            if (r.test.hasOwnProperty('sk')) {
                $('#awp_sp_test_sk').val(r.test.sk);
            }

            if (r.test.hasOwnProperty('client_id')) {
                $('#awp_sp_test_client_id').val(r.test.client_id);
            }

            if (r.test.hasOwnProperty('connection_type')) {
                $("input[name='test[connection_type]'][value=" + r.test.connection_type + "]").prop('checked', true);
            }

            
            // if (r.test.hasOwnProperty('account_webhook_url')) {
            //     $('#test_account_webhook_url').val(r.test.account_webhook_url);
            // }

            if (r.test.hasOwnProperty('account_webhook_signing_secrect')) {
                $('#awp_sp_test_account_webhook_signing_secrect').val(r.test.account_webhook_signing_secrect);
            }

            // if (r.test.hasOwnProperty('application_webhook_url')) {
            //     $('#test_application_webhook_url').val(r.test.application_webhook_url);
            // }

            if (r.test.hasOwnProperty('application_webhook_signing_secrect')) {
                $('#awp_sp_test_application_webhook_signing_secrect').val(r.test.application_webhook_signing_secrect);
            }

            if (r.live.hasOwnProperty('pk')) {
                $('#awp_sp_live_pk').val(r.live.pk);
            }

            if (r.live.hasOwnProperty('sk')) {
                $('#awp_sp_live_sk').val(r.live.sk);
            }

            if (r.live.hasOwnProperty('client_id')) {
                $('#live_client_id').val(r.live.client_id);
            }

            if (r.live.hasOwnProperty('connection_type')) {
                $("input[name='live[connection_type]'][value=" + r.live.connection_type + "]").prop('checked', true);
            }
            
            // if (r.test.hasOwnProperty('account_webhook_url')) {
            //     $('#live_account_webhook_url').val(r.test.account_webhook_url);
            // }

            if (r.live.hasOwnProperty('account_webhook_signing_secrect')) {
                $('#awp_sp_live_account_webhook_signing_secrect').val(r.live.account_webhook_signing_secrect);
            }

            // if (r.test.hasOwnProperty('application_webhook_url')) {
            //     $('#live_application_webhook_url').val(r.test.application_webhook_url);
            // }

            if (r.live.hasOwnProperty('application_webhook_signing_secrect')) {
                $('#awp_sp_live_application_webhook_signing_secrect').val(r.live.application_webhook_signing_secrect);
            }

            $('#awp_sp_admin_stripe_account_integration_settings_form').loader('hide');

        });

    }
    /* End - Get Stripe Account INtegration */


    /* Start - Post Stripe Account INtegration */
    $('#awp_sp_admin_stripe_account_integration_settings_form #submit_btn').on('click', function(e) {
        e.preventDefault();
        $('#awp_sp_admin_stripe_account_integration_settings_form').loader('show');
        // var self = $(this);
        // var loaderContainer = $('<span/>', {
        //     'class': 'loader-image-container'
        // }).insertAfter(self);
        // var loader = $('<img/>', {
        //     src: 'http://aff.localhost.com/wp-admin/images/loading.gif',
        //     'class': 'loader-image'
        // }).appendTo(loaderContainer);
        var data = {
            action: 'update_stripe_account_integration_settings',
            security: stripe_account_integration_settings.ajax.nonce,
            access_mode: $('input[name="access_mode"]:checked').val(),
            account_id: $('#awp_sp_account_id').val(),
            test: {
                pk: $('input[name="test[pk]"]').val(),
                sk: $('input[name="test[sk]"]').val(),
                client_id: $('input[name="test[client_id]"]').val(),
                connection_type: $('input[name="test[connection_type]"]:checked').val(),
                // application_webhook_url: $('input[name="test[application_webhook_url]"]').val(),
                application_webhook_signing_secrect: $('input[name="test[application_webhook_signing_secrect]"]').val(),
                // account_webhook_url: $('input[name="test[account_webhook_url]"]').val(),
                account_webhook_signing_secrect: $('input[name="test[account_webhook_signing_secrect]"]').val(),
            },

            live: {
                pk: $('input[name="live[pk]"]').val(),
                sk: $('input[name="live[sk]"]').val(),
                client_id: $('input[name="live[client_id]"]').val(),
                connection_type: $('input[name="live[connection_type]"]:checked').val(),
                // application_webhook_url: $('input[name="live[application_webhook_url]"]').val(),
                application_webhook_signing_secrect: $('input[name="live[application_webhook_signing_secrect]"]').val(),
                // account_webhook_url: $('input[name="live[account_webhook_url]"]').val(),
                account_webhook_signing_secrect: $('input[name="live[account_webhook_signing_secrect]"]').val(),
            },

        };

        $.ajax({
            method: 'POST',
            url: stripe_account_integration_settings.ajax.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', stripe_account_integration_settings.ajax.nonce);
            },
            data: data
        }).then(function(r) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.success(stripe_account_integration_settings.ajax.messages.success);
            // loaderContainer.remove();
            $('#awp_sp_admin_stripe_account_integration_settings_form').loader('hide');
            window.location.reload(true);
        }).fail(function(r) {
            var message = stripe_account_integration_settings.ajax.messages.error;
            if (r.hasOwnProperty('message')) {
                message = r.message;
            }
            // $('#awp_sp_admin_stripe_account_integration_settings_form').find('.alert').html('<p>' + message + '</p>');
            alertify.set('notifier', 'position', 'top-right');
            alertify.error(stripe_account_integration_settings.ajax.messages.error);
        });
    });
    /* End - Post Stripe Account INtegration */

})(jQuery, window);