(function($, w) {
    'use strict';

    $(document).ready(function() {
        // console.log("ejaz testing profile");

        /* Start - Get Profile Details */

        if ($('#awp_sp_admin_stripe_account_profile_summary').length > 0) {
            $('#awp_sp_admin_stripe_account_profile_summary').loader('show');
            $.ajax({
                method: 'POST',
                url: stripe_account_profile.ajax.url,
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', stripe_account_profile.ajax.nonce);
                },
                data: {
                    action: 'stripe_account_profile_action',
                    security: stripe_account_profile.ajax.nonce
                },
            }).then(function(r) {
                // console.log("Profile = " + JSON.stringify(r.data));
                // console.log( typeof(r.data) );
                // console.log( r.data.country );
                if( r.data.hasOwnProperty('settings') ) {
                    if (r.data.settings.hasOwnProperty('dashboard')) {
                        if (r.data.settings.dashboard.hasOwnProperty('display_name')) {
                            $('#asp_account').text(r.data.settings.dashboard.display_name);
                        }
                    }
                    if (r.data.hasOwnProperty('country')) {
                        $('#asp_country').text(r.data.country);
                    }
                    if (r.data.hasOwnProperty('default_currency')) {
                        $('#asp_currency').text(r.data.default_currency);
                    }
                }
                $('#awp_sp_admin_stripe_account_profile_summary').loader('hide');
            });
        }
        /* End - Get Profile Details */

    });

})(jQuery, window);