(function($, w) {
    'use strict';

    $.fn.get_afen_account_authorized_tab_content = function() {
        if ($('#afen_account_authorized_settings_form').length > 0) {
            $('#afen_account_authorized_settings_form').loader('show');
            $.ajax({
                method: 'POST',
                url: afen_account_autorized_settings.ajax.url,
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', afen_account_autorized_settings.ajax.nonce);
                },
                data: {
                    action: 'get_afen_account_autorized_settings',
                    security: afen_account_autorized_settings.ajax.nonce,
                },
            }).then(function(r) {
                // console.log("R = " + JSON.stringify(r));
                if (r.hasOwnProperty('account_id')) {
                    $('#account_id').val(r.account_id);
                }

                if (r.hasOwnProperty('email_status')) {
                    $("#afen_account_authorized_settings_form input[name=email_status][value=" + r.email_status + "]").prop('checked', true);
                }

                // if (r.hasOwnProperty('email_recipient')) {
                //     $('#afen_aa_email_recipient').val(r.email_recipient);
                // }
                if (r.hasOwnProperty('email_subject')) {
                    $('#afen_aa_email_subject').val(r.email_subject);
                }
                if (r.hasOwnProperty('email_body')) {
                    $('#afen_aa_email_body').val(r.email_body);
                    $.fn.tmce_setContent(r.email_body, 'afen_aa_email_body');
                }
                // if (r.hasOwnProperty('email_recipient')) {
                //     $('#afen_aa_email_recipient').val(r.email_recipient);
                // }

                $('#afen_account_authorized_settings_form').loader('hide');
            });
        }
    }

    if( localStorage.getItem('activeTab') == '#v-pills-affiliate-account-authorized' ){
        $.fn.get_afen_account_authorized_tab_content();
    }else{
        $('a.nav-link').on('shown.bs.tab', function(event) {
            if ($(event.target).attr('id') == 'v-pills-affiliate-account-authorized-tab') {
                $.fn.get_afen_account_authorized_tab_content();
            }
        });
    }

    $('#afen_account_authorized_settings_form').on('submit', function(e) {
        e.preventDefault();
        $('#afen_account_authorized_settings_form').loader('show');
        var email_status = $(this).find('input[name="email_status"]:checked').val();
        // var email_recipient = $(this).find('input[name="email_recipient"]').val();
        var email_subject = $(this).find('input[name="email_subject"]').val();
        var email_body = $.fn.tmce_getContent('afen_aa_email_body');

        var data = {
            action: 'update_afen_account_autorized_settings',
            security: afen_account_autorized_settings.ajax.nonce,
            email_status: email_status,
            // email_recipient: email_recipient,
            email_subject: email_subject,
            email_body: email_body,
        };

        $.ajax({
            method: 'POST',
            url: afen_account_autorized_settings.ajax.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', afen_account_autorized_settings.ajax.nonce);
            },
            data: data
        }).then(function(r) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.success(afen_account_autorized_settings.ajax.messages.success);
            // loaderContainer.remove();
            $('#afen_account_authorized_settings_form').loader('hide');
        }).fail(function(r) {
            var message = afen_account_autorized_settings.ajax.messages.error;
            if (r.hasOwnProperty('message')) {
                message = r.message;
            }
            alertify.set('notifier', 'position', 'top-right');
            alertify.error(afen_account_autorized_settings.ajax.messages.error);
        });
    });

})(jQuery, window);