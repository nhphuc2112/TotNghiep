(function($, w) {
    'use strict';

    /* Start - Stripe Manual Payout  */
    $('.awp_sp_stripe_referral_manual_payout').on('click', function(e) {
        e.preventDefault();
        // console.log("referral Span = " + JSON.parse(JSON.stringify($(this).find('span').text())));
        // var referral = JSON.parse(JSON.stringify($(this).find('span').text()));
        var referral = JSON.parse($(this).find('span').text());
        // console.log(typeof(referral));
        $('table').loader('show');
        var data = {
            action: 'create_stripe_manual_payout',
            security: stripe_create_manual_payout.ajax.nonce,
            affiliate_id: referral.affiliate_id,
            referral: {
                id: referral.referral_id,
                amount: referral.amount,
                currency: referral.currency,
                status: referral.status
            },
        };
        // console.log("Data = " + JSON.stringify(data));
        $.ajax({
            method: 'POST',
            url: stripe_create_manual_payout.ajax.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', stripe_create_manual_payout.ajax.nonce);
            },
            data: data
        }).then(function(r) {
            // console.log('stripe_create_manual_payout - case 01');
            /**
             * Alertify JS Notification
             */
            alertify.set('notifier', 'position', 'top-right');
            alertify.set('notifier', 'delay', 2);
            var notification;
            if (r.success) {
                // console.log('stripe_create_manual_payout - case 02');
                notification = alertify.success(stripe_create_manual_payout.ajax.messages.success);
            } else {
                // console.log('stripe_create_manual_payout - case 03');
                var html = stripe_create_manual_payout.ajax.messages.error;
                html += "<br\> <b>Stripe Error Code:</b> "+r.data.code;
                html += "<br\> <b>Stripe Error message:</b> "+r.data.message;
                notification = alertify.error(html);
            }
            notification.ondismiss = function() {
                // console.log('dismissed');
                // $('table').loader('hide');
                window.location.reload();
            };
        }).fail(function(r) {
            var message = stripe_manual_payout.strings.error;
            if (r.hasOwnProperty('message')) {
                message = r.message;
            }
            // console.log('stripe_create_manual_payout - case 04');
            /**
             * Alertify JS Notification  
             */
            alertify.set('notifier', 'position', 'top-right');
            alertify.set('notifier', 'delay', 2);
            var notification = alertify.error(stripe_create_manual_payout.ajax.messages.error);
            notification.ondismiss = function() {
                // console.log('dismissed');
                window.location.reload();
            };
        });
    });
    /* End - Stripe Account Balance Post Request  */

})(jQuery, window);