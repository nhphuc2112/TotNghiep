(function($) {
    if ($('#awp-sp-schedules-listing-tbl-form').length > 0) {
        schedules_list = {
            /** added method display
             * for getting first sets of data
             **/
            display: function() {
                $('#awp-sp-schedules-listing-tbl-form').loader('show');
                $.ajax({
                    method: 'POST',
                    url: schedules_listing.ajax.display.url,
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', schedules_listing.ajax.display.nonce);
                    },
                    data: {
                        action: schedules_listing.ajax.display.action,
                        security: schedules_listing.ajax.display.nonce,
                    },
                }).then(function(r) {
                    $("#awp-sp-schedules-listing-tbl").html(r.data);
                    $("tbody").on("click", ".toggle-row", function(e) {
                        e.preventDefault();
                        $(this).closest("tr").toggleClass("is-expanded")
                    });
                    schedules_list.init();
                    $('#awp-sp-schedules-listing-tbl-form').loader('hide');
                }).fail(function(r) {});
            },
            init: function() {
                var timer;
                var delay = 500;
                $('.tablenav-pages a, .manage-column.sortable a, .manage-column.sorted a').on('click', function(e) {
                    e.preventDefault();
                    var query = this.search.substring(1);
                    // console.log("query = " + query);
                    var data = {
                        paged: schedules_list.__query(query, 'paged') || '1',
                        order: schedules_list.__query(query, 'order') || 'asc',
                        orderby: schedules_list.__query(query, 'orderby') || 'title'
                    };
                    schedules_list.update(data);
                });
                /* Prevent Enter Key on Form */
                $('#awp-sp-schedules-listing-tbl-form').bind('keydown', function(e) {
                    if (e.keyCode == 13 || e.which == 13) {
                        e.preventDefault();
                        return false;
                    }
                });
                $('input[name=paged]').on('keyup').on('keyup', function(e) {
                    e.preventDefault();
                    var paged_value = $(this).val();
                    if (paged_value.length == 0) {
                        return false;
                    }
                    var data = {
                        paged: parseInt($('input[name=paged]').val()) || '1',
                        order: $('input[name=order]').val() || 'asc',
                        orderby: $('input[name=orderby]').val() || 'title'
                    };
                    window.clearTimeout(timer);
                    timer = window.setTimeout(function() {
                        schedules_list.update(data);
                    }, delay);
                });
                $('.search-box input[type="search"]').off('keyup').on('keyup', function(e) {
                    // console.log("Searching...");
                    e.preventDefault();
                    var search_value = $(this).val();
                    // if (search_value.length == 0) {
                    //     return false;
                    // }
                    var data = {
                        search_value: search_value,
                    };
                    window.clearTimeout(timer);
                    timer = window.setTimeout(function() {
                        schedules_list.update(data);
                    }, delay);
                });
                $('#search-submit').off('click').on('click', function(e) {
                    e.preventDefault();
                    $(this).prop('type', 'button');
                    //  setAttribute OR attr functions can be used
                    var search_value = $('input[type="search"]').val();
                    if (search_value.length == 0) {
                        return false;
                    }
                    // console.log("Searching btn... = " + search_value);
                    var data = {
                        search_value: $(this).val(),
                    };
                    window.clearTimeout(timer);
                    timer = window.setTimeout(function() {
                        schedules_list.update(data);
                    }, delay);
                });
                /* Start - Single Schedule Delete  */
                $('.delete_btn').on('click', function(e) {
                    e.preventDefault();
                    // console.log("deletig...");
                    var data = {
                        id: $(this).attr('id'),
                    };
                    window.clearTimeout(timer);
                    timer = window.setTimeout(function() {
                        schedules_list.delete(data);
                    }, delay);
                });
                /* End - Single Schedule Delete  */
                /* Start - Single Schedule Execution  */
                $('.execute_btn').on('click', function(e) {
                    e.preventDefault();
                    // console.log("executing...");
                    var data = {
                        id: $(this).attr('id'),
                    };
                    window.clearTimeout(timer);
                    timer = window.setTimeout(function() {
                        schedules_list.execute(data);
                    }, delay);
                });
                /* End - Single Schedule Execution  */
                /* Start - Bulk Delete */
                /* Selection */
                $('select[name="action"], select[name="action2"]').change(function() {
                    if ($(this).val() == 'delete') {
                        /* Disabled Apply Button if noone box can be checked */
                        if ($('input[name="schedule_id[]"]:checked').length == 0) {
                            $('.bulkactions #doaction, .bulkactions #doaction2').prop('disabled', 'disabled');
                        }
                    } else {
                        /* Enable Apply Button if delete Action not Selected from DropDown */
                        $('.bulkactions #doaction, .bulkactions #doaction2').prop('disabled', '');
                    }
                });
                /* Processing Ajax */
                $('.bulkactions #doaction, .bulkactions #doaction2').on('click', function(e) {
                    // $('table').loader('show');
                    var action = $('select[name="action"] option:selected').val();
                    var action2 = $('select[name="action2"] option:selected').val();
                    if (action == 'delete' || action2 == 'delete') {
                        e.preventDefault();
                        // console.log("bulk deleting...");
                        var schedules_ids = [];
                        $('input[name="schedule_id[]"]:checked').each(function() {
                            schedules_ids.push($(this).val());
                        });
                        // console.log("Schedules IDs = " + schedules_ids);
                        var data = {
                            schedules_ids: schedules_ids,
                        };
                        window.clearTimeout(timer);
                        timer = window.setTimeout(function() {
                            schedules_list.bulk_delete(data);
                        }, delay);
                    }
                });
                /* End - Bulk Delete */
                /* Start - Bulk Execution */
                /* Selection */
                $('select[name="action"], select[name="action2"]').change(function() {
                    if ($(this).val() == 'execute') {
                        /* Disabled Apply Button if noone box can be checked */
                        if ($('input[name="schedule_id[]"]:checked').length == 0) {
                            $('.bulkactions #doaction, .bulkactions #doaction2').prop('disabled', 'disabled');
                        }
                    } else {
                        /* Enable Apply Button if execute Action not Selected from DropDown */
                        $('.bulkactions #doaction, .bulkactions #doaction2').prop('disabled', '');
                    }
                });
                /* Processing Ajax */
                $('.bulkactions #doaction, .bulkactions #doaction2').on('click', function(e) {
                    // $('table').loader('show');
                    var action = $('select[name="action"] option:selected').val();
                    var action2 = $('select[name="action2"] option:selected').val();
                    if (action == 'execute' || action2 == 'execute') {
                        e.preventDefault();
                        // console.log("bulk executing...");
                        var schedules_ids = [];
                        $('input[name="schedule_id[]"]:checked').each(function() {
                            schedules_ids.push($(this).val());
                        });
                        // console.log("Schedules IDs = " + schedules_ids);
                        var data = {
                            schedules_ids: schedules_ids,
                        };
                        window.clearTimeout(timer);
                        timer = window.setTimeout(function() {
                            schedules_list.bulk_execute(data);
                        }, delay);
                    }
                });
                /* End - Bulk Execution */
            },
            /** AJAX call
             * Send the call and replace table parts with updated version!
             * @param    object    data The data to pass through AJAX
             */
            update: function(data) {
                $('#awp-sp-schedules-listing-tbl-form').loader('show');
                $.ajax({
                    url: schedules_listing.ajax.history.url,
                    data: $.extend({
                        action: schedules_listing.ajax.history.action,
                        security: schedules_listing.ajax.history.nonce,
                    }, data),
                }).then(function(r) {
                    if ($('#awp-sp-schedules-listing-tbl-form').length > 0) {
                        var response = $.parseJSON(r);
                        if (response.rows.length)
                            $('#the-list').html(response.rows);
                        if (response.column_headers.length)
                            $('thead tr, tfoot tr').html(response.column_headers);
                        if (response.pagination.bottom.length)
                            $('.tablenav.top .tablenav-pages').html($(response.pagination.top).html());
                        if (response.pagination.top.length)
                            $('.tablenav.bottom .tablenav-pages').html($(response.pagination.bottom).html());
                        schedules_list.init();
                        $('#awp-sp-schedules-listing-tbl-form').loader('hide');
                    }

                }).fail(function(r) {});
            },
            delete: function(data) {
                $('.delete_btn[id="' + data.id + '"]').parents('tr').loader('show');
                $($('.delete_btn[id="' + data.id + '"]').parents('tr').find('.row-action-processing')).toggleClass('d-none');
                $.ajax({
                    method: 'POST',
                    url: schedules_listing.ajax.actions.delete.url,
                    data: $.extend({
                        action: schedules_listing.ajax.actions.delete.action,
                        security: schedules_listing.ajax.actions.delete.nonce,
                    }, data),
                }).then(function(r) {
                    if (r.hasOwnProperty('data')) {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.set('notifier', 'delay', 2);
                        if (r.data.hasOwnProperty('deleted') && r.data.deleted == 1) {
                            alertify.success(schedules_listing.ajax.actions.delete.messages.success);
                        } else {
                            alertify.error(schedules_listing.ajax.actions.delete.messages.error);
                        }
                    }
                    /*$('.delete_btn[id="' + data.id + '"]').parents('tr').fadeOut(1000);*/
                    $('.delete_btn[id="' + data.id + '"]').parents('tr').fadeOut(1000, function(){
                        if( $($('.delete_btn[id="' + data.id + '"]').parents('tbody').find('tr')).length == 1 ){
                            $('.delete_btn[id="' + data.id + '"]').parents('tbody').append('<tr class="no-items"><td class="colspanchange" colspan="8">No items found.</td></tr>');
                        }
                        $(this).remove();
                    });
                    $($('.delete_btn[id="' + data.id + '"]').parents('tr').find('.row-action-processing')).toggleClass('d-none');
                    $('.delete_btn[id="' + data.id + '"]').parents('tr').loader('hide');

                }).fail(function(r) {
                    var message = schedules_listing.ajax.actions.delete.messages.error;
                    if (r.hasOwnProperty('message')) {
                        message = r.message;
                    }
                    alertify.set('notifier', 'position', 'top-right');
                    alertify.set('notifier', 'delay', 2);
                    alertify.error(message);
                    $($('.delete_btn[id="' + data.id + '"]').parents('tr').find('.row-action-processing')).toggleClass('d-none');
                    $('.delete_btn[id="' + data.id + '"]').parents('tr').loader('hide');
                });
            },
            execute: function(data){
                $('.execute_btn[id="' + data.id + '"]').parents('tr').html();
                $('.execute_btn[id="' + data.id + '"]').parents('tr').loader('show');
                $($('.execute_btn[id="' + data.id + '"]').parents('tr').find('.row-action-processing')).toggleClass('d-none');
                $.ajax({
                    method: 'POST',
                    url: schedules_listing.ajax.actions.execute.url,
                    data: $.extend({
                        action: schedules_listing.ajax.actions.execute.action,
                        security: schedules_listing.ajax.actions.execute.nonce,
                    }, data),
                }).then(function(r) {
                    // if (r.hasOwnProperty('data')) {
                    //     if (r.data.hasOwnProperty('failed') && r.data.failed.length > 0) {
                    //         alertify.set('notifier', 'position', 'top-right');
                    //         alertify.error(schedules_listing.ajax.actions.execute.messages.error);
                    //     } else {
                    //         alertify.set('notifier', 'position', 'top-right');
                    //         alertify.success(schedules_listing.ajax.actions.execute.messages.success);
                    //     }
                    // }
                    
                    alertify.set('notifier', 'position', 'top-right');
                    alertify.set('notifier', 'delay', 2);
                    if (r.success) {
                        alertify.success(schedules_listing.ajax.actions.execute.messages.success);
                    } else {
                        alertify.success(schedules_listing.ajax.actions.execute.messages.error);
                    }
                    $('.execute_btn[id="' + data.id + '"]').parents('tr').loader('hide');
                    $($('.execute_btn[id="' + data.id + '"]').parents('tr').find('.row-action-processing')).toggleClass('d-none');
                }).fail(function(r) {
                    var message = schedules_listing.ajax.actions.execute.messages.error;
                    if (r.hasOwnProperty('message')) {
                        message = r.message;
                    }
                    alertify.set('notifier', 'position', 'top-right');
                    alertify.set('notifier', 'delay', 2);
                    alertify.error(message);
                    $('.execute_btn[id="' + data.id + '"]').parents('tr').loader('hide');
                    $($('.execute_btn[id="' + data.id + '"]').parents('tr').find('.row-action-processing')).toggleClass('d-none');
                });
            },
            bulk_delete: function(data){
                $('#awp-sp-schedules-listing-tbl-form').loader('show');
                $(data.schedules_ids).each(function(i){
                    // console.log(data.schedules_ids[i]);
                    // row loader
                    // $('.delete_btn[id="' + data.schedules_ids[i] + '"]').parents('tr').loader('show');
                    $($('.delete_btn[id="' + data.schedules_ids[i] + '"]').parents('tr').find('.row-action-processing')).toggleClass('d-none');
                });
                $.ajax({
                    method: 'POST',
                    url: schedules_listing.ajax.actions.bulk_delete.url,
                    data: $.extend({
                        action: schedules_listing.ajax.actions.bulk_delete.action,
                        security: schedules_listing.ajax.actions.bulk_delete.nonce,
                    }, data),
                }).then(function(r) {
                    if (r.hasOwnProperty('data')) {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.set('notifier', 'delay', 2);
                        if (r.data.hasOwnProperty('deleted') && r.data.deleted == 1) {
                            alertify.success(schedules_listing.ajax.actions.bulk_delete.messages.success);
                        } else {
                            alertify.error(schedules_listing.ajax.actions.bulk_delete.messages.error);
                        }
                    }
                    $('#awp-sp-schedules-listing-tbl-form').loader('hide');
                    $(data.schedules_ids).each(function(i){
                        $($('.delete_btn[id="' + data.schedules_ids[i] + '"]').parents('tr').find('.row-action-processing')).toggleClass('d-none');
                        // $('.delete_btn[id="' + data.schedules_ids[i] + '"]').parents('tr').fadeOut(1000);
                        $('.delete_btn[id="' + data.schedules_ids[i] + '"]').parents('tr').fadeOut(1000, function(){
                            if( $($('.delete_btn[id="' + data.schedules_ids[i] + '"]').parents('tbody').find('tr')).length == 1 ){
                                $('.delete_btn[id="' + data.schedules_ids[i] + '"]').parents('tbody').append('<tr class="no-items"><td class="colspanchange" colspan="8">No items found.</td></tr>');
                            }
                            $(this).remove();
                        }); 
                    });
                }).fail(function(r) {
                    var message = schedules_listing.ajax.actions.bulk_delete.messages.error;
                    if (r.hasOwnProperty('message')) {
                        message = r.message;
                    }
                    alertify.set('notifier', 'position', 'top-right');
                    alertify.set('notifier', 'delay', 2);
                    alertify.error(message);
                    $('#awp-sp-schedules-listing-tbl-form').loader('hide');
                });
            },
            bulk_execute: function(data){
                $('#awp-sp-schedules-listing-tbl-form').loader('show');
                $(data.schedules_ids).each(function(i){
                    // console.log(data.schedules_ids[i]);
                    // row loader
                    // $('.execute_btn[id="' + data.schedules_ids[i] + '"]').parents('tr').loader('show');
                    $($('.execute_btn[id="' + data.schedules_ids[i] + '"]').parents('tr').find('.row-action-processing')).toggleClass('d-none');
                });
                $.ajax({
                    method: 'POST',
                    url: schedules_listing.ajax.actions.bulk_execute.url,
                    data: $.extend({
                        action: schedules_listing.ajax.actions.bulk_execute.action,
                        security: schedules_listing.ajax.actions.bulk_execute.nonce,
                    }, data),
                }).then(function(r) {
                    if (r.hasOwnProperty('data')) {
                        alertify.set('notifier', 'position', 'top-right');
                        alertify.set('notifier', 'delay', 2);
                        if (r.data.hasOwnProperty('failed') && r.data.failed.length > 0) {
                            alertify.error(schedules_listing.ajax.actions.bulk_execute.messages.error);
                        } else {
                            alertify.success(schedules_listing.ajax.actions.bulk_execute.messages.success);
                        }
                    }
                    $('#awp-sp-schedules-listing-tbl-form').loader('hide');
                    $(data.schedules_ids).each(function(i){
                        $($('.execute_btn[id="' + data.schedules_ids[i] + '"]').parents('tr').find('.row-action-processing')).toggleClass('d-none');
                    });
                }).fail(function(r) {
                    var message = schedules_listing.ajax.actions.bulk_execute.messages.error;
                    if (r.hasOwnProperty('message')) {
                        message = r.message;
                    }
                    alertify.set('notifier', 'position', 'top-right');
                    alertify.error(schedules_listing.ajax.actions.bulk_execute.messages.error);
                });
            },
            /**
             * Filter the URL Query to extract variables
             *
             * @see http://css-tricks.com/snippets/javascript/get-url-variables/
             *
             * @param    string    query The URL query part containing the variables
             * @param    string    variable Name of the variable we want to get
             *
             * @return   string|boolean The variable value if available, false else.
             */
            __query: function(query, variable) {
                var vars = query.split("&");
                // console.log("vars = " + vars);
                for (var i = 0; i < vars.length; i++) {
                    var pair = vars[i].split("=");
                    if (pair[0] == variable)
                        return pair[1];
                }
                return false;
            },
        }
        schedules_list.display();
    }
})(jQuery);