(function($, w) {
    'use strict';

    /* Help:-  https://stackoverflow.com/questions/901115/how-can-i-get-query-string-values-in-javascript/901144#901144 */
    $.fn.getQueryStringByName = function(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, '\\$&');
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

    // console.log("Query String ID = " + $.fn.getQueryStringByName('id'));

    /* Start - Get Schedule */
    if ($('#awp_sp_edit_schedule_form').length > 0) {
        $('#awp_sp_edit_schedule_form #awp_sp_sef_sds').loader('show');
        var data = {
            action: 'get_schedule',
            security: get_schedule.ajax.nonce,
            id: $.fn.getQueryStringByName('id')
        };
        // console.log("Dat = " + JSON.stringify(data));
        $.ajax({
            method: 'POST',
            url: get_schedule.ajax.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', get_schedule.ajax.nonce);
            },
            data: data
        }).then(function(r) {
            // console.log("Get Schedule r = " + JSON.stringify(r));
            if (r.hasOwnProperty('data')) {
                if (r.data.hasOwnProperty('status')) {
                    $("input[name=awp_sp_sef_status][value=" + r.data.status + "]").prop('checked', true);
                    // $('input[name="access_mode"]').val(r.access_mode);
                }
                if (r.data.hasOwnProperty('title')) {
                    $('#awp_sp_sef_title').val(r.data.title);
                }
                if (r.data.hasOwnProperty('days')) {
                    $('#awp_sp_sef_days').val(r.data.days);
                }
                if (r.data.hasOwnProperty('hours')) {
                    $('#awp_sp_sef_hours').val(r.data.hours);
                }
                if (r.data.hasOwnProperty('minutes')) {
                    $('#awp_sp_sef_minutes').val(r.data.minutes);
                }
                if (r.data.hasOwnProperty('seconds')) {
                    $('#awp_sp_sef_seconds').val(r.data.seconds);
                }
                if (r.data.hasOwnProperty('interval')) {
                    $('#awp_sp_sef_interval').val(r.data.interval);
                }
                if (r.data.hasOwnProperty('first_execution_time')) {
                    $('#awp_sp_sef_fet').val(r.data.first_execution_time);
                    var start_date_time_inpt = moment(r.data.first_execution_time).format('YYYY-MM-DD hh:mm:ss A');
                    $.fn.schedules_fet_date_time_picker('awp_sp_sef_fet', 'YYYY-MM-DD hh:mm:ss A', start_date_time_inpt);
                }



                // jQuery("#awp_sp_sef_fet").datepicker({
                //     dateFormat: "dd-mm-yy"
                // });
            }
            $('#awp_sp_edit_schedule_form #awp_sp_sef_sds').loader('hide');
        }).fail(function(r) {});
    }
    /* End - Get Schedule */

    /* Start - Get Included & Excluded Affiliates */
    if ($('#awp_sp_edit_schedule_affilities_include_exclude').length > 0) {
        $('#awp_sp_edit_schedule_affilities_include_exclude select').DualListBox({
            // defaults
            element: $(this).context,
            available: {
                ajax: {
                    url: edit_schedule_get_affiliates.ajax.included.url,
                    method: 'POST',
                    data: {
                        action: 'edit_schedule_get_included_affiliates',
                        security: edit_schedule_get_affiliates.ajax.included.nonce,
                        id: $.fn.getQueryStringByName('id')
                    },
                },
                ui: {
                    title: 'Included Affiliates',
                },
                search: {
                    placeholder: 'Search Affiliates'
                }
            },
            selected: {
                ajax: {
                    url: edit_schedule_get_affiliates.ajax.excluded.url,
                    method: 'POST',
                    data: {
                        action: 'edit_schedule_get_excluded_affiliates',
                        security: edit_schedule_get_affiliates.ajax.excluded.nonce,
                        id: $.fn.getQueryStringByName('id')
                    },
                },
                ui: {
                    title: 'Excluded Affiliates',
                },
                search: {
                    placeholder: 'Search Affiliates'
                }
            },
            parent_id: 'awp_sp_edit_schedule_affilities_include_exclude',
            value: 'user_id',
            text: 'user_name',
            // json: true,
            timeout: 500,
            horizontal: false,
            textLength: 45,
            moveAllBtn: true,
            maxAllBtn: 500,
            selectClass: 'form-control',
            warning: 'Are you sure you want to move this many items? Doing so can cause your browser to become unresponsive.'
        });
    }
    /* End - Get Included & Excluded Affiliates */


    /* Calculate Schedule Interval in Seconds */
    $(".awp_sp_sef_icf").on("keyup", function() {
        var sum = 0;
        $(".awp_sp_sef_icf").each(function() {
            var id = $(this).attr('id');
            var value = $(this).val();
            var seconds = 0;
            if (id == 'awp_sp_sef_seconds') {
                seconds = value;
            } else if (id == 'awp_sp_sef_minutes') {
                seconds = (value * 60);
            } else if (id == 'awp_sp_sef_hours') {
                seconds = ((value * 60) * 60);
            } else if (id == 'awp_sp_sef_days') {
                seconds = (((value * 60) * 60) * 24);
            }
            sum += +seconds;
        });
        $('#awp_sp_sef_interval').val(sum);
    });

    /* Start - Update Schedule */
    $('#awp_sp_edit_schedule_form').on('submit', function(e) {
        e.preventDefault();
        $('#awp_sp_edit_schedule_form').loader('show');
        var data = {
            action: 'edit_schedule',
            security: edit_schedule.ajax.nonce,
            id: $.fn.getQueryStringByName('id'),
            title: $('#awp_sp_sef_title').val(),
            status: $('input[name="awp_sp_sef_status"]:checked').val(),
            days: $('#awp_sp_sef_days').val(),
            first_execution_time: $('#awp_sp_sef_fet').val(),
            hours: $('#awp_sp_sef_hours').val(),
            minutes: $('#awp_sp_sef_minutes').val(),
            seconds: $('#awp_sp_sef_seconds').val(),
            interval: $('#awp_sp_sef_interval').val(),
            excluded_affiliates: $('#awp_sp_edit_schedule_affilities_include_exclude').getSelected(),
        };
        $.ajax({
            method: 'POST',
            url: edit_schedule.ajax.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', edit_schedule.ajax.nonce);
            },
            data: data
        }).then(function(r) {
            if (r.hasOwnProperty('data')) {
                if (r.data.hasOwnProperty('updated') && r.data.updated == 1) {
                    alertify.set('notifier', 'position', 'top-right');
                    alertify.success(edit_schedule.ajax.messages.success);
                } else {
                    alertify.set('notifier', 'position', 'top-right');
                    alertify.error(edit_schedule.ajax.messages.error);
                }
            }
            $('#awp_sp_edit_schedule_form').loader('hide');
        }).fail(function(r) {
            var message = edit_schedule.ajax.messages.error;
            if (r.hasOwnProperty('message')) {
                message = r.message;
            }
            alertify.set('notifier', 'position', 'top-right');
            alertify.error(edit_schedule.ajax.messages.error);
        });
    });
    /* End - Update Scedule */


})(jQuery, window);