(function($, w) {
    'use strict';

    /* Start - Get Stripe Account INtegration */
    if ($('#awp_sp_admin_general_settings_form').length > 0) {
        $('#awp_sp_admin_general_settings_form').loader('show');
        $.ajax({
            method: 'POST',
            url: general_settings.ajax.get.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', general_settings.ajax.get.nonce);
            },
            data: {
                action: general_settings.ajax.get.action,
                security: general_settings.ajax.get.nonce,
            },
        }).then(function(r) {
            // console.log("R = " + JSON.stringify(r));
            
            if (r.deactivation.hasOwnProperty('delete_stripe_integration_settings')) {
                $("input[name=delete_stripe_integration_settings][value=" + r.deactivation.delete_stripe_integration_settings + "]").prop('checked', true);
            }
            if (r.deactivation.hasOwnProperty('delete_stripe_connected_accounts')) {
                $("input[name=delete_stripe_connected_accounts][value=" + r.deactivation.delete_stripe_connected_accounts + "]").prop('checked', true);
            }
            if (r.deactivation.hasOwnProperty('delete_schedules')) {
                $("input[name=delete_schedules][value=" + r.deactivation.delete_schedules + "]").prop('checked', true);
            }
            if (r.deactivation.hasOwnProperty('delete_admin_emails_settings')) {
                $("input[name=delete_admin_emails_settings][value=" + r.deactivation.delete_admin_emails_settings + "]").prop('checked', true);
            }
            if (r.deactivation.hasOwnProperty('delete_affiliate_emails_settings')) {
                $("input[name=delete_affiliate_emails_settings][value=" + r.deactivation.delete_affiliate_emails_settings + "]").prop('checked', true);
            }
            if (r.deactivation.hasOwnProperty('affiliate_log_settings')) {
                $("input[name=affiliate_log_settings][value=" + r.deactivation.affiliate_log_settings + "]").prop('checked', true);
            }
            if (r.deactivation.hasOwnProperty('affiliate_delete_stripe_log')) {
                $("input[name=affiliate_delete_stripe_log][value=" + r.deactivation.affiliate_delete_stripe_log + "]").prop('checked', true);
            }
            $('#awp_sp_admin_general_settings_form').loader('hide');

        });

    }
    /* End - Get Stripe Account INtegration */


    /* Start - Post Stripe Account INtegration */
    $('#awp_sp_admin_general_settings_form #submit_btn').on('click', function(e) {
        e.preventDefault();
        $('#awp_sp_admin_general_settings_form').loader('show');
        var data = {
            action: general_settings.ajax.update.action,
            security: general_settings.ajax.update.nonce,
            deactivation: {
                delete_stripe_integration_settings: $('input[name="delete_stripe_integration_settings"]:checked').val(),
                delete_stripe_connected_accounts: $('input[name="delete_stripe_connected_accounts"]:checked').val(),
                delete_schedules: $('input[name="delete_schedules"]:checked').val(),
                delete_admin_emails_settings: $('input[name="delete_admin_emails_settings"]:checked').val(),
                delete_affiliate_emails_settings: $('input[name="delete_affiliate_emails_settings"]:checked').val(),
                affiliate_log_settings: $('input[name="affiliate_log_settings"]:checked').val(),
                affiliate_delete_stripe_log: $('input[name="affiliate_delete_stripe_log"]:checked').val(),
            },
        };

        $.ajax({
            method: 'POST',
            url: general_settings.ajax.update.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', general_settings.ajax.update.nonce);
            },
            data: data
        }).then(function(r) {
            alertify.set('notifier', 'position', 'top-right');
            alertify.success(general_settings.ajax.update.messages.success);
            $('#awp_sp_admin_general_settings_form').loader('hide');
        }).fail(function(r) {
            var message = general_settings.ajax.update.messages.error;
            if (r.hasOwnProperty('message')) {
                message = r.message;
            }
           alertify.set('notifier', 'position', 'top-right');
            alertify.error(general_settings.ajax.update.messages.error);
        });
    });
    /* End - Post Stripe Account INtegration */

})(jQuery, window);