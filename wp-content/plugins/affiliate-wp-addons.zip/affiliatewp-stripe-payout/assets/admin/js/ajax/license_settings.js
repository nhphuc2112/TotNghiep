(function($, w) {
    'use strict';

    /* Start - Get License Settings */
    var get_fnc_executed = false;
    if ($('#awp_sp_license_settings_form').length > 0) {
        $('#awp_sp_license_settings_form').loader('show');
        $.ajax({
            method: 'POST',
            url: license_settings.ajax.get.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', license_settings.ajax.get.nonce);
            },
            data: {
                action: license_settings.ajax.get.action,
                security: license_settings.ajax.get.nonce,
            }, 
        }).then(function(r) {
            // console.log("R type = " + typeof(r));
            // console.log("R = " + JSON.stringify(r));
            
            if (r.data.hasOwnProperty('key')) {
                // console.log('Key = '+r.data.key);
                $('#awp_sp_license_key').val(r.data.key);
            }

            if (r.data.hasOwnProperty('status') && r.data.key != null && r.data.key != '' ) {
                $('#awp_sp_license_edd_action').prop("disabled", false);
                
                $('#awp_sp_license_current_status').text(r.data.status);
                get_fnc_executed = true;
                if(r.data.status !== 'valid' ){
                    $('#awp_sp_license_edd_action').bootstrapToggle('on');
                }else{
                    $('#awp_sp_license_key').attr('disabled','disabled');
                    $('#awp_sp_license_edd_action').bootstrapToggle('off');
                }

            }

            $('#awp_sp_license_settings_form').loader('hide');
            get_fnc_executed = false;
        });
    }
    /* End - Get License Setting */


    /* Start - Post Stripe Account INtegration */
    // $('#awp_sp_license_settings_form #submit_btn').on('click', function(e) {
    //     e.preventDefault();
    $('#awp_sp_license_edd_action').on('change',function() {
        
        if( get_fnc_executed == true ){
            return
        }else{
            // console.log('changed');
        }
        $('#awp_sp_license_settings_form').loader('show');
        var license_activate_or_deactivate_action = 'activate';
            if($('#awp_sp_license_edd_action').prop("checked") != false){
                license_activate_or_deactivate_action = 'deactivate';
            }
        var data = {
            action: license_settings.ajax.update.action,
            security: license_settings.ajax.update.nonce,
            license_edd_action: license_activate_or_deactivate_action,
            settings_option: 'license_key',
            license_key: $('#awp_sp_license_key').val(),
        };
        $.ajax({
            method: 'POST',
            url: license_settings.ajax.update.url,
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', license_settings.ajax.update.nonce);
            },
            data: data
        }).then(function(r) {
            // alertify.set('notifier', 'position', 'top-right');
            // alertify.success(license_settings.ajax.update.messages.success);
            $('#awp_sp_license_settings_form').loader('hide');
            window.location.reload(true);
        }).fail(function(r) {
            // var message = license_settings.ajax.update.messages.error;
            // if (r.hasOwnProperty('message')) {
            //     message = r.message;
            // }
            //    alertify.set('notifier', 'position', 'top-right');
            //     alertify.error(license_settings.ajax.update.messages.error);
            $('#awp_sp_license_settings_form').loader('hide');
            window.location.reload(true);
        });
    });
    /* End - Post Stripe Account INtegration */

})(jQuery, window);