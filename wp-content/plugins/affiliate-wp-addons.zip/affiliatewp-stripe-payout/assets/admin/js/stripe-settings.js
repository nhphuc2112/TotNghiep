(function($, w) {
    'use strict';

    // click events
    document.body.addEventListener('click', copy, true);

    // event handler
    function copy(e) {
        // find target element
        var 
          t = e.target,
          c = t.dataset.copytarget,
          inp = (c ? document.querySelector(c) : null);
        // is element selectable?
        if (inp && inp.select) {
          // select text
          inp.select();
          try {
            // copy text
            document.execCommand('copy');
            inp.blur();
            // copied animation
            t.classList.add('copied');
            setTimeout(function() { t.classList.remove('copied'); }, 1500);
          }
          catch (err) {
            alert('please press Ctrl/Cmd+C to copy');
          }
        }
    }

    $(document).ready(function() {
        /**
         * Stripe API Keys Switch according access-mode 
         */
        $('input[name="access_mode"]').change(function() {
            if ($(this).val() == 'test') {
                // console.log("Access Mode = Test");
                $('.awp_sp_stripe_live_integration').addClass("d-none");
                $('.awp_sp_stripe_test_integration').removeClass("d-none");
                $('#awp_sp_account_balance_section').removeClass("d-none");
            } else if ($(this).val() == 'live') {
                // console.log("Access Mode = Live");
                $('.awp_sp_stripe_live_integration').removeClass("d-none");
                $('.awp_sp_stripe_test_integration').addClass("d-none");
                $('#awp_sp_account_balance_section').addClass("d-none");
            }
        });
    });
})(jQuery, window);