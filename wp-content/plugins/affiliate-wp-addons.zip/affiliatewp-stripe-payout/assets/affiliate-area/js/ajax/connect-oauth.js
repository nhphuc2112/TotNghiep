(function($, w) {
    'use strict';

    $(document).ready(function() {

        if (typeof(awp_sp_connect_oauth.affiliate_connect_oauth_data[0]) == 'object') {
            $('.affiliate_connect_oauth .message').text(awp_sp_connect_oauth.affiliate_connect_oauth_data[0].message);
            if (stripe_connect_oauth_object.affiliate_connect_oauth_data[0].status == true) {
                $('.affiliate_connect_oauth .account_id').text(stripe_connect_oauth_object.affiliate_connect_oauth_data[0].account_id);
            }
        }

                /**
         * Start by Ejaz at 27 Oct, 2021
         */
        // if ($('#awpsp_standard_new_account_connect_oauth_url').length > 0) {
        //     console.log('awpsp_standard_new_account_connect_oauth_url - case 01');
        $('#awpsp_standard_new_account_connect_oauth_url').click(function () {
            console.log('awpsp_standard_new_account_connect_oauth_url - case 02');
            $.ajax({
                method: 'POST',
                url: awp_sp_connect_oauth.ajax.url,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', awp_sp_connect_oauth.ajax.standard.new_account.nonce);
                },
                data: {
                    action: awp_sp_connect_oauth.ajax.standard.new_account.action,
                    security: awp_sp_connect_oauth.ajax.standard.new_account.nonce,
                },
            }).then(function (r) {
                // console.log(" Standard Connect Oauth URL = " + JSON.stringify(r));
                if (r.data.hasOwnProperty('standard_connect_oauth_new_account_url')) {
                    w.location = r.data.standard_connect_oauth_new_account_url;
                }
            });
        });
    // }else{
    //     console.log('awpsp_standard_new_account_connect_oauth_url - case 03');
    // }
    if ($('#awpsp_standard_existing_account_connect_oauth_url').length > 0) {
        $('#awpsp_standard_existing_account_connect_oauth_url').click(function () {
            $.ajax({
                method: 'POST',
                url: awp_sp_connect_oauth.ajax.url,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', awp_sp_connect_oauth.ajax.standard.existing_account.nonce);
                },
                data: {
                    action: awp_sp_connect_oauth.ajax.standard.existing_account.action,
                    security: awp_sp_connect_oauth.ajax.standard.existing_account.nonce,
                },
            }).then(function (r) {
                // console.log(" Standard Connect Oauth URL = " + JSON.stringify(r));
                if (r.data.hasOwnProperty('standard_connect_oauth_existing_account_url')) {
                    w.location = r.data.standard_connect_oauth_existing_account_url;
                }
            });
        });
    }

    if ($('#awpsp_express_new_account_connect_oauth_url').length > 0) {
        $('#awpsp_express_new_account_connect_oauth_url').click(function () {
            $.ajax({
                method: 'POST',
                url: awp_sp_connect_oauth.ajax.url,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', awp_sp_connect_oauth.ajax.express.new_account.nonce);
                },
                data: {
                    action: awp_sp_connect_oauth.ajax.express.new_account.action,
                    security: awp_sp_connect_oauth.ajax.express.new_account.nonce,
                },
            }).then(function (r) {
                // console.log(" Standard Connect Oauth URL = " + JSON.stringify(r));
                if (r.data.hasOwnProperty('express_connect_oauth_new_account_url')) {
                    w.location = r.data.express_connect_oauth_new_account_url;
                }
            });
        });
    }
    if ($('#awpsp_express_existing_account_connect_oauth_url').length > 0) {
        $('#awpsp_express_existing_account_connect_oauth_url').click(function () {
            $.ajax({
                method: 'POST',
                url: awp_sp_connect_oauth.ajax.url,
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', awp_sp_connect_oauth.ajax.express.existing_account.nonce);
                },
                data: {
                    action: awp_sp_connect_oauth.ajax.express.existing_account.action,
                    security: awp_sp_connect_oauth.ajax.express.existing_account.nonce,
                },
            }).then(function (r) {
                // console.log(" Standard Connect Oauth URL = " + JSON.stringify(r));
                if (r.data.hasOwnProperty('express_connect_oauth_existing_account_url')) {
                    w.location = r.data.express_connect_oauth_existing_account_url;
                }
            });
        });
    }
    /**
     * End by Ejaz at 27 Oct, 2021
     */

        /**
         * Commented by Ejaz at 27 Oct, 2021
         */
        /* Start - Stripe Standard Connect Oauth *
        if ($('#stripe_standard_connect_oauth').length > 0) {
            $('#stripe_standard_connect_oauth').click(function () {
                $.ajax({
                    method: 'POST',
                    url: awp_sp_connect_oauth.ajax.standard.url,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', awp_sp_connect_oauth.ajax.standard.nonce);
                    },
                    data: {
                        action: awp_sp_connect_oauth.ajax.standard.action,
                        security: awp_sp_connect_oauth.ajax.standard.nonce,
                    },
                }).then(function (r) {
                    // console.log(" Standard Connect Oauth URL = " + JSON.stringify(r));
                    if( r.data.hasOwnProperty('standard_connect_oauth_url') ){
                        w.location = r.data.standard_connect_oauth_url;
                    }
                });
            });
        }
        /* End - Stripe Standard Connect Oauth */

        /**
         * Commented by Ejaz at 27 Oct, 2021
         */
        /* Start - Stripe Express Connect Oauth *
        if ($('#stripe_express_connect_oauth').length > 0) {
            $('#stripe_express_connect_oauth').click(function () {
                $.ajax({
                    method: 'POST',
                    url: awp_sp_connect_oauth.ajax.express.url,
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', awp_sp_connect_oauth.ajax.express.nonce);
                    },
                    data: {
                        action: awp_sp_connect_oauth.ajax.express.action,
                        security: awp_sp_connect_oauth.ajax.express.nonce,
                    },
                }).then(function (r) {
                    // console.log(" express Connect Oauth URL = " + JSON.stringify(r));
                    if( r.data.hasOwnProperty('express_connect_oauth_url') ){
                        w.location = r.data.express_connect_oauth_url;
                    }
                });
            });
        }
        /* End - Stripe Express Connect Oauth */

    });

})(jQuery, window);