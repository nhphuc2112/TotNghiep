(function($, w) {
    'use strict';

    $(document).ready(function() {
        // console.log('affiliate_connect_oauth_data = ' + typeof(stripe_connect_oauth_object.affiliate_connect_oauth_data));
        // console.log('affiliate_connect_oauth_data = ' + stripe_connect_oauth_object.affiliate_connect_oauth_data);
        // console.log('affiliate_connect_oauth_data = ' + JSON.stringify(stripe_connect_oauth_object.affiliate_connect_oauth_data));
        // if (typeof(stripe_connect_oauth_object.affiliate_connect_oauth_data[0]) == 'object') {
        //     $('.affiliate_connect_oauth .message').text(stripe_connect_oauth_object.affiliate_connect_oauth_data[0].message);
        //     // console.log('Status = ' + typeof(stripe_connect_oauth_object.affiliate_connect_oauth_data[0].status));
        //     if (stripe_connect_oauth_object.affiliate_connect_oauth_data[0].status == true) {
        //         $('.affiliate_connect_oauth .account_id').text(stripe_connect_oauth_object.affiliate_connect_oauth_data[0].account_id);
        //     }
        // }
        // $('.get_stripe_connect_oauth_url_btn').on('click', function(e) {
        //     e.preventDefault();
        //     // $('#get_stripe_connect_oauth_url_btn').loader('show');
        //     var stripe_connect_oauth_url;
        //     if ($(this).attr('id') == 'stripe_express_connect_oauth') {
        //         // console.log('case 01');
        //         stripe_connect_oauth_url = stripe_connect_oauth_object.express_connect_oauth_url;
        //     } else if ($(this).attr('id') == 'stripe_standard_connect_oauth') {
        //         // console.log('case 02');
        //         stripe_connect_oauth_url = stripe_connect_oauth_object.standard_connect_oauth_url;
        //     }
        //     // console.log('stripe_connect_oauth_url = ' + stripe_connect_oauth_url);
        //     w.location = stripe_connect_oauth_url;
        // });
    });



})(jQuery, window);