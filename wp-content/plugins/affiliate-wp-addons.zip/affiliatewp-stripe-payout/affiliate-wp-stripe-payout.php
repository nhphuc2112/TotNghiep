<?php
/**
 * Plugin Name: AffiliateWP Stripe Payout
 * Plugin URI: https://wooninjas.com/downloads/affiliatewp-stripe-payout/
 * Description: This addon allows you to pay the referrals from your Stripe account to the connected individual or multiple affiliates via an automated scheduled cron-job or manually with the single click or bulk action. it will save the payouts processing time and boost the affiliates' satisfaction by giving them quick access to their funds.
 * Version: 1.2.0
 * Requires at least: 5.2
 * Requires PHP: 7.2
 * Author: WooNinjas
 * Author URI: https://wooninjas.com/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: AWP-SP
 * Domain Path: /languages
 */

 // If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * PSR-4 Composer Autoloader
 */
if ( file_exists( dirname( __FILE__ ) . '/includes/lib/autoload.php' ) ) {
	require_once dirname( __FILE__ ) . '/includes/lib/autoload.php';
}

/* Start - Plugin Global Constants */
/* 
* Help :- https://wp-mix.com/php-wordpress-path/
*/
define( 'AWP_SP_Name', 'AffiliateWP Stripe Payout' );
define( 'AWP_SP_VERSION', '1.2.0' );
define( 'AWP_SP_URI', 'https://wooninjas.com/downloads/affiliatewp-stripe-payout/' );
/**
 * Plugin Text Domain
*/
define( 'AWP_SP_TEXT_DOMAIN', 'AWP-SP' );
/**
 * Plugin Directories Paths
 */
define( 'AWP_SP_BASE_URL', get_bloginfo('url'));
define( 'AWP_SP_DIR_INT', __FILE__ );
define( 'AWP_SP_BASE_DIR', plugin_basename( __FILE__ ) );
define( 'AWP_SP_DIR', plugin_dir_path( __FILE__ ) );
define( 'AWP_SP_DIR_FILE', AWP_SP_DIR . basename( __FILE__ ) );
define( 'AWP_SP_TEMPLATES_DIR', trailingslashit( AWP_SP_DIR . 'templates' ) );
define( 'AWP_SP_ASSETS_DIR', trailingslashit( AWP_SP_DIR . 'assets' ) );
/** 
* Plugin URLS
*/
// define( 'AWP_SP_URL', trailingslashit( plugins_url( '', __FILE__ ) ) );
define( 'AWP_SP_URL', trailingslashit( plugin_dir_url( __FILE__ ) ) );
define( 'AWP_SP_ASSETS_URL', trailingslashit( AWP_SP_URL . 'assets' ) );
/* End - Plugin Global Constants */

if( ! function_exists('get_plugin_data') ){
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

/**
* Activation Hook
*/
register_activation_hook( AWP_SP_DIR_INT, array(  new \AWPSP\Bootstrap\AWP_SP_Activate(), 'plugin_activation_manager') );
/**
* Deactivation Hook
*/
register_deactivation_hook( AWP_SP_DIR_INT, array(  new \AWPSP\Bootstrap\AWP_SP_Deactivate(), 'plugin_deactivation_manager'));

/**
* App Bootstraping
*/
function awp_sp_bootstrap() {
    $AWPSP = \AWPSP\Bootstrap\AWP_SP::get_instance();
	if ( ! $AWPSP->validate_requirements() ) {
		return false; 
	}else{
        do_action('awp_sp_loaded');
    }
}
add_action( 'plugins_loaded', 'awp_sp_bootstrap' );
