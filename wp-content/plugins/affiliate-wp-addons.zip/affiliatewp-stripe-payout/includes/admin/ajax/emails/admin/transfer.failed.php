<?php
namespace AWPSP\Admin\Ajax\Emails\Admin;
/**
 * ADENSA = Admin Email Notification Settings Ajax
 * TF = Transfer Failed
 * Stripe Event =  transfer.failed
 * WebHook = Stripe Application WebHook
 */
use AWPSP\Admin\Settings\Emails\Admin\ADENS_TF;

if (! class_exists('\AWPSP\Admin\Ajax\Emails\Admin\ADENSA_TF')) {
    class ADENSA_TF
    {

        /**
		 * Traits used inside class
		 */
        use \AWPSP\Traits\AllTraits;

        public function __construct()
        {
            /**
             * Ajax JS  Request's Client Setup
             */
            add_action('admin_enqueue_scripts', array($this, 'ajax_js_client_setup'), 10, 1);
            /**
             * Ajax PHP Post Request's Handler Setup
             */
            add_action('wp_ajax_update_aden_transfer_failed_settings', array($this, 'update_aden_transfer_failed_settings'));
            add_action('wp_ajax_get_aden_transfer_failed_settings', array($this, 'get_aden_transfer_failed_settings'));
        }

        public function ajax_js_client_setup()
        {
            if( isset( $_GET['page'] ) && $_GET['page'] == 'awp-sp-admin-dashboard'  ) {
                wp_register_script('awp-sp-aden-transfer-failed-settings-js', AWP_SP_ASSETS_URL . 'admin/js/ajax/email-notifications/admin/aden_transfer_failed_settings.js', array('jquery', 'awp-sp-email_notifications_admin_ui-js'), '4.1.0', true);
                wp_localize_script('awp-sp-aden-transfer-failed-settings-js', 'aden_transfer_failed_settings', array(
                    'ajax' => array(
                        'url' => esc_url_raw(admin_url('admin-ajax.php')),
                        'nonce' => wp_create_nonce('ajax_aden_transfer_failed_settings_nonce'),
                        'messages' => array(
                            'success' => '<b>'.__('Congratulation!', AWP_SP_TEXT_DOMAIN).'</b> <br/> '.__('The email settings are updated.', AWP_SP_TEXT_DOMAIN),
                            'error' => '<b>'.__('Sorry!', AWP_SP_TEXT_DOMAIN).'</b> <br/> '.__('The email settings are not updated.', AWP_SP_TEXT_DOMAIN),
                        ),
                    ),
                ));
                wp_enqueue_script('awp-sp-aden-transfer-failed-settings-js');
            }
        }

        public function update_aden_transfer_failed_settings()
        {
            if (check_ajax_referer('ajax_aden_transfer_failed_settings_nonce', 'security')) {
                // print_r($_POST);
                $settings = array(
                    'email_status' => $_POST['email_status'],
                    'email_recipient' => $_POST['email_recipient'],
                    'email_subject' => $_POST['email_subject'],
                    'email_body' => $_POST['email_body'],
                );
                ADENS_TF::save_settings($settings);
                $this->log(__('Transfer Failed email updated', AWP_SP_TEXT_DOMAIN) );
                return wp_send_json_success(ADENS_TF::get_settings());
            } else {
                return wp_send_json_error(array('status_code' => 498, 'message' => __('Security Token Verification is failed', AWP_SP_TEXT_DOMAIN) ));
            }
        }

        public function get_aden_transfer_failed_settings()
        {
            if (check_ajax_referer('ajax_aden_transfer_failed_settings_nonce', 'security')) {
                return wp_send_json(ADENS_TF::get_settings());
            } else {
                return wp_send_json_error(array('status_code' => 498, 'message' => __('Security Token Verification is failed', AWP_SP_TEXT_DOMAIN) ));
            }
        }
    }
}
