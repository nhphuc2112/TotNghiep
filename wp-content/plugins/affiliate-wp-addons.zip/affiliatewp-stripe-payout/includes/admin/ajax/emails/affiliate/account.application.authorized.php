<?php
namespace AWPSP\Admin\Ajax\Emails\Affiliate;
/**
 * AFENSA = Affiliate Email Notification Settings Ajax
 * AAA = Account Application Authorized
 * Stripe Event =  account.application.authorized
 * WebHook = Stripe Application WebHook
 */
use AWPSP\Admin\Settings\Emails\Affiliate\AFENS_AAA;

if (! class_exists('\AWPSP\Admin\Ajax\Emails\Affiliate\AFENSA_AAA')) {
    class AFENSA_AAA
    {

        /**
		 * Traits used inside class
		 */
        use \AWPSP\Traits\AllTraits;

        public function __construct()
        {
            /**
             * Ajax JS  Request's Client Setup
             */
            add_action('admin_enqueue_scripts', array($this, 'ajax_js_client_setup'), 10, 1);
            /**
             * Ajax PHP Post Request's Handler Setup
             */
            add_action('wp_ajax_update_afen_account_autorized_settings', array($this, 'update_afen_account_autorized_settings'));
            add_action('wp_ajax_get_afen_account_autorized_settings', array($this, 'get_afen_account_autorized_settings'));
        }

        public function ajax_js_client_setup()
        {
            if( isset( $_GET['page'] ) && $_GET['page'] == 'awp-sp-admin-dashboard'  ) {
                wp_register_script('awp-sp-afen-account-autorized-settings-js', AWP_SP_ASSETS_URL . 'admin/js/ajax/email-notifications/affiliate/afen_account_autorized_settings.js', array('jquery', 'awp-sp-email_notifications_admin_ui-js'), '4.1.0', true);
                wp_localize_script('awp-sp-afen-account-autorized-settings-js', 'afen_account_autorized_settings', array(
                    'ajax' => array(
                        'url' => esc_url_raw(admin_url('admin-ajax.php')),
                        'nonce' => wp_create_nonce('ajax_afen_account_autorized_settings_nonce'),
                        'messages' => array(
                            'success' => '<b>'.__('Congratulation!', AWP_SP_TEXT_DOMAIN).'</b> <br/> '.__('The email settings are updated.', AWP_SP_TEXT_DOMAIN),
                            'error' => '<b>'.__('Sorry!', AWP_SP_TEXT_DOMAIN).'</b> <br/> '.__('The email settings are not updated.', AWP_SP_TEXT_DOMAIN),
                        ),
                    ),
                ));
                wp_enqueue_script('awp-sp-afen-account-autorized-settings-js');
            }
        }

        public function update_afen_account_autorized_settings()
        {
            if (check_ajax_referer('ajax_afen_account_autorized_settings_nonce', 'security')) {
                // print_r($_POST);
                $settings = array(
                    'email_status' => $_POST['email_status'],
                    'email_recipient' => $_POST['email_recipient'],
                    'email_subject' => $_POST['email_subject'],
                    'email_body' => $_POST['email_body'],
                );
                AFENS_AAA::save_settings($settings);
                $this->log(__('Account authorized email is updated', AWP_SP_TEXT_DOMAIN) );
                return wp_send_json_success(AFENS_AAA::get_settings());
            } else {
                return wp_send_json_error(array('status_code' => 498, 'message' => __('Security Token Verification is failed', AWP_SP_TEXT_DOMAIN) ));
            }
        }

        public function get_afen_account_autorized_settings()
        {
            if (check_ajax_referer('ajax_afen_account_autorized_settings_nonce', 'security')) {
                return wp_send_json(AFENS_AAA::get_settings());
            } else {
                return wp_send_json_error(array('status_code' => 498, 'message' => __('Security Token Verification is failed', AWP_SP_TEXT_DOMAIN) ));
            }
        }
    }
}
