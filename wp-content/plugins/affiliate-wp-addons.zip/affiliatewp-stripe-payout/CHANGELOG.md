# Changelog

## 1.2.0
- New: File based system log.
- Fix: Only connected account with complete profile can be paid.
- Fix: Added detailed stripe messages on admin side affiliates listing and affilate area shortcode.
- Fix: Updates on the admin side manual payout option.
- Fix: Stripe return link to the website.
- Fix: UI issue on the General Setting page.
- Fix: Code tweaks

## 1.1.2
- New Feature: The multilingual support added to the add-on.
- Improvement: The timestamp additional parameter is added to license API requests.
- Fix: Fixed the Stripe API Version auto conversion issue.
- Fix: Fixed the cron-job failer issue in case of insufficient balance for scheduled payout. 

## 1.1.1
- Fix: Fixed the activation & deactivation issue.
- Fix: Fixed the admin settings test-mode & live-mode switching issue.
- Fix: Fixed the stripe API Version issue, so now is working on API old version using stripe accounts. 
- Fix: Fixed the amount multiplication by 100 regarding the Zeo-decimal currencies. 
- Fix: Fixed the admin default currency selection issue.

## 1.1
- New Feature: The Affiliate Stripe's Connection status is added under the affiliates listing Name column.
- Improvement: Emails Notifications Templates with useful shortcodes.
- Fix: Fixed the stripe connect standard account onboarding issues regarding Stripe SDK v7.72.0.
- Fix: Fixed the stripe's connect express account onboarding issues regarding Stripe SDK v7.720.
- Fix: Fixed the Not connected affiliate's  referral 'stripe payout' link visibility issue
- Fix: Fixed the auto-execution issues of scheduled referrals payments.
- Fix: Fixed the UI issues and typos.

## 1.0
- Initial
