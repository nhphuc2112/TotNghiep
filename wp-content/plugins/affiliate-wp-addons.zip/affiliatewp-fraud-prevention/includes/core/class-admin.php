<?php
/**
 * Fraud Prevention Admin
 *
 * @package     AffiliateWP Fraud Prevention
 * @subpackage  Core
 * @copyright   Copyright (c) 2022, Awesome Motive Inc
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0
 */

namespace AffiliateWP_Fraud_Prevention\Core;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin class.
 * Registers submenu and handles sending emails.
 *
 * @since 1.0
 */
class Admin {

	/**
	 * Get things started.
	 *
	 * @access public
	 * @since  1.0
	 **/
	public function __construct() {

		add_filter( 'affwp_settings_tabs', array( $this, 'setting_tab' ) );
		add_filter( 'affwp_settings', array( $this, 'register_settings' ) );

		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ), 100 );

		add_filter( 'affwp_referral_table_referral_id', array( $this, 'referrals_table_add_flag_to_referral_id_column' ), 20, 2 );
		add_filter( 'affwp_visit_table_visit_id', array( $this, 'visits_table_add_flag_to_visit_id_column' ), 20, 2 );

		add_filter( 'affwp_edit_referral_bottom', array( $this, 'display_flag_section_on_edit_referral_screen' ) );
		add_filter( 'affwp_referral_table_single_row_class', array( $this, 'add_class_to_table_row' ), 10, 2 );
		add_filter( 'affwp_visit_table_single_row_class', array( $this, 'add_class_to_table_row' ), 10, 2 );
	}

	/**
	 * Registers the new settings tab.
	 *
	 * @since 1.0
	 *
	 * @param array $tabs Setting tabs.
	 * @return array Array of settings tabs.
	 */
	public function setting_tab( $tabs ) {
		$tabs['fraud-prevention'] = __( 'Anti-Fraud', 'affiliatewp-fraud-prevention' );
		return $tabs;
	}

	/**
	 * Registers the settings.
	 *
	 * @since 1.0
	 *
	 * @param array $settings Affiliate Portal settings.
	 * @return array Array of settings.
	 */
	public function register_settings( $settings ) {

		$settings['fraud-prevention'] = array(
			'fraud_prevention_self_referrals'      => array(
				'name'     => __( 'Self-Referrals', 'affiliatewp-fraud-prevention' ),
				'desc'     => __( 'Whether an affiliate can earn a commission on their own purchases.', 'affiliatewp-fraud-prevention' ),
				'type'     => 'radio',
				'options'  => array(
					'allow'  => _x( 'Allow - Self-referrals are allowed.', 'self-referrals', 'affiliatewp-fraud-prevention' ),
					'flag'   => _x( 'Flag - Self-referrals are allowed but the referrals will be flagged as potentially fraudulent.', 'self-referrals', 'affiliatewp-fraud-prevention' ),
					'reject' => _x( 'Reject - Self-referrals are not allowed.', 'self-referrals', 'affiliatewp-fraud-prevention' ),
				),
				'callback' => array( $this, 'self_referrals_callback' ),
				'std'  => 'reject',
			),
			'fraud_prevention_conversion_rate'     => array(
				'name'    => __( 'Conversion Rate', 'affiliatewp-fraud-prevention' ),
				'desc'    => __( 'Checks if an affiliate’s conversion rate (referrals to visits ratio) is within the defined limits. The affiliate must have at least 10 referrals before this is detected.', 'affiliatewp-fraud-prevention' ),
				'type'    => 'radio',
				'options' => array(
					'allow' => _x( 'Allow - Affiliates can generate referrals regardless of their conversion rate.', 'conversion rate', 'affiliatewp-fraud-prevention' ),
					'flag'  => _x( 'Flag - Visits and referrals will be flagged if the affiliate’s conversion rate was outside of the defined limits when the visit or referral was created. ', 'conversion rate', 'affiliatewp-fraud-prevention' ),
				),
				'std'  => 'allow',
			),
			'fraud_prevention_min_conversion_rate' => array(
				'name' => __( 'Minimum Conversion Rate (%)', 'affiliatewp-fraud-prevention' ),
				'desc' => __( 'Minimum conversion rate', 'affiliatewp-fraud-prevention' ),
				'type' => 'number',
				'size' => 'small',
				'step' => '0.01',
				'std'  => '2',
			),
			'fraud_prevention_max_conversion_rate' => array(
				'name' => __( 'Maximum Conversion Rate (%)', 'affiliatewp-fraud-prevention' ),
				'desc' => __( 'Maximum conversion rate', 'affiliatewp-fraud-prevention' ),
				'type' => 'number',
				'size' => 'small',
				'step' => '0.01',
				'std'  => '20',
			),
		);

		if ( affiliate_wp()->settings->get( 'allow_affiliate_registration' ) ) {
			$referring_sites = array(
				'fraud_prevention_referring_sites' => array(
					'name'    => __( 'Referring Sites', 'affiliatewp-fraud-prevention' ),
					'desc'    => __( 'The referring site is checked against the URL in the affiliate’s application.', 'affiliatewp-fraud-prevention' ),
					'type'    => 'radio',
					'options' => array(
						'allow'  => _x( 'Allow - Affiliates can generate a visit (and thus referral) from any referring site.', 'referring sites', 'affiliatewp-fraud-prevention' ),
						'flag'   => _x( 'Flag - Affiliates can generate a visit and referral if the referring site does not match the URL listed in the affiliate’s application but the visit and referral will be flagged as potentially fraudulent.', 'referring sites', 'affiliatewp-fraud-prevention' ),
						'reject' => _x( 'Reject - Visits will not be recorded (and thus referrals will not be generated) since the referring site does not match the URL listed in the affiliate’s application.', 'referring sites', 'affiliatewp-fraud-prevention' ),
					),
					'std'  => 'allow',
				),
			);

			$settings['fraud-prevention'] = array_slice( $settings['fraud-prevention'], 0, 2, true ) + $referring_sites + array_slice( $settings['fraud-prevention'], 2, null, true );
		}

		return $settings;
	}

	/**
	 * Admin scripts.
	 *
	 * @since 1.0
	 */
	public function admin_scripts() {

		if ( ! in_array( affwp_get_current_screen(), array( 'affiliate-wp-referrals', 'affiliate-wp-visits', 'affiliate-wp-settings' ), true ) ) {
			return;
		}

		wp_register_style( 'affwp-fp', AFFWP_FP_PLUGIN_URL . 'assets/css/admin.css', array(), AFFWP_FP_VERSION );

		wp_register_script( 'affwp-fp-popper', AFFWP_FP_PLUGIN_URL . 'assets/js/popper.min.js', array(), AFFWP_FP_VERSION );
		wp_register_script( 'affwp-fp-tippy', AFFWP_FP_PLUGIN_URL . 'assets/js/tippy-bundle.umd.min.js', array( 'affwp-fp-popper' ), AFFWP_FP_VERSION );
		wp_register_script( 'affwp-fp', AFFWP_FP_PLUGIN_URL . 'assets/js/admin-scripts.js', array(
			'affwp-fp-popper',
			'affwp-fp-tippy',
		), AFFWP_FP_VERSION );

		// Enqueue.
		affwp_enqueue_style( 'affwp-fp', 'fraud-prevention' );

		affwp_enqueue_script( 'affwp-fp-popper', 'fraud-prevention' );
		affwp_enqueue_script( 'affwp-fp-tippy', 'fraud-prevention' );
		affwp_enqueue_script( 'affwp-fp', 'fraud-prevention' );
	}

	/**
	 * Add flag to the referral id column in referrals list table to indicate a flagged referral.
	 *
	 * @since 1.0
	 *
	 * @param $value
	 * @param \AffWP\Referral $referral Referral object.
	 * @return mixed|string
	 */
	function referrals_table_add_flag_to_referral_id_column( $value, $referral ) {

		if ( ! empty( $referral->flag ) ) {
			$flag_url = AFFWP_FP_PLUGIN_URL . 'assets/images/flag.svg';

			$value .= sprintf( ' <img data-tippy-content="%1$s" src="%2$s" height="16" width="16" class="affwp-fp-flag" />', $this->get_referral_flag_label( $referral->flag ), $flag_url );
		}

		return $value;
	}

	/**
	 * Add flag to the visit id column in visits list table to indicate a flagged visit.
	 *
	 * @since 1.0
	 *
	 * @param $value
	 * @param \AffWP\Visit $visit Visit object.
	 * @return mixed|string
	 */
	function visits_table_add_flag_to_visit_id_column( $value, $visit ) {

		if ( ! empty( $visit->flag ) ) {
			$flag_url = AFFWP_FP_PLUGIN_URL . 'assets/images/flag.svg';

			$value .= sprintf( ' <img data-tippy-content="%1$s" src="%2$s" height="16" width="16" class="affwp-fp-flag" />', $this->get_visit_flag_label( $visit->flag ), $flag_url );
		}

		return $value;
	}

	/**
	 * Display the flag section on the edit referral screen.
	 *
	 * @since 1.0
	 *
	 * @param \AffWP\Referral $referral Referral object.
	 * @return void
	 */
	public function display_flag_section_on_edit_referral_screen( $referral ) {
		$payout   = affwp_get_payout( $referral->payout_id );
		$disabled = disabled( (bool) $payout, true, false );
		?>
		<table class="form-table">
			<tr class="form-row">
				<th scope="row">
					<label for="flag"><?php esc_html_e( 'Flag', 'affiliatewp-fraud-prevention' ); ?></label>
				</th>
				<td>
					<select name="flag" id="flag" <?php echo esc_attr( $disabled ); ?>>
						<option value=""<?php selected( '', $referral->flag ); ?>><?php esc_html_e( 'Select a Flag', 'affiliatewp-fraud-prevention' ); ?></option>
						<option value="self_referral"<?php selected( 'self_referral', $referral->flag ); ?>><?php esc_html_e( 'Self-referral', 'affiliatewp-fraud-prevention' ); ?></option>
						<option value="referring_site"<?php selected( 'referring_site', $referral->flag ); ?>><?php esc_html_e( 'Referring Site', 'affiliatewp-fraud-prevention' ); ?></option>
						<option value="conversion_rate"<?php selected( 'conversion_rate', $referral->flag ); ?>><?php esc_html_e( 'Conversion Rate', 'affiliatewp-fraud-prevention' ); ?></option>
					</select>
					<?php if ( $payout ) : ?>
						<p class="description"><?php esc_html_e( 'The referral flag cannot be changed once it has been included in a payout.', 'affiliatewp-fraud-prevention' ); ?></p>
					<?php else : ?>
						<p class="description"><?php esc_html_e( 'Select the flag for this referral.', 'affiliatewp-fraud-prevention' ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Add CSS class to referral/visit row that has a flag.
	 *
	 * @since 1.0
	 *
	 * @param string                       $class  CSS class.
	 * @param \AffWP\Referral|\AffWP\Visit $object Referral or visit object
	 * @return string
	 */
	public function add_class_to_table_row( $class, $object )  {

		if ( ! empty( $object->flag ) ) {
			$class .= empty( $class ) ? 'affwp-fp-flagged-row' : ' affwp-fp-flagged-row';
		}

		return $class;
	}

	/**
	 * Callback for the "Self-Referrals" settings.
	 *
	 * @since 1.0
	 *
	 * @param $args Arguments passed by the self-referrals settings.
	 * @return void
	 */
	public function self_referrals_callback( $args ) {

		if ( function_exists( 'affiliatewp_allow_own_referrals' ) ) {
			unset( $args['id'] );
			$args['std']      = 'allow';
			$args['disabled'] = true;
			$args['desc']     = __( 'The Allow Own Referrals add-on is active. Please deactivate it to select another option.', 'affiliatewp-fraud-prevention' );
		}

		affiliate_wp()->settings->radio_callback( $args );
	}

	/**
	 * Retrieves the label for a referral flag.
	 *
	 * @since 1.0
	 *
	 * @param string $flag Flag
	 * @return false The localized version of the referral flag label.
	 */
	private function get_referral_flag_label( $flag ) {
		switch ( $flag ) {
			case 'self_referral':
				$description = __( 'This referral was flagged because the customer used their own affiliate link.', 'affiliatewp-fraud-prevention' );
				break;

			case 'referring_site':
				$description = __( 'This referral was flagged because the referring site does not match the URL listed in the affiliate’s application.', 'affiliatewp-fraud-prevention' );
				break;

			case 'conversion_rate':
				$description = __( 'This referral was flagged because the affiliate conversion rate was outside of the defined limits.', 'affiliatewp-fraud-prevention' );
				break;

			default:
				$description = $flag;
				break;
		}

		return $description;
	}

	/**
	 * Retrieves the label for a visit flag.
	 *
	 * @since 1.0
	 *
	 * @param string $flag Flag
	 * @return string The localized version of the visit flag label.
	 */
	private function get_visit_flag_label( $flag ) {
		switch ( $flag ) {
			case 'self_referral':
				$description = __( 'This visit was flagged because the customer used their own affiliate link.', 'affiliatewp-fraud-prevention' );
				break;

			case 'referring_site':
				$description = __( 'This referral was flagged because the referring site does not match the URL listed in the affiliate’s application.', 'affiliatewp-fraud-prevention' );
				break;

			case 'conversion_rate':
				$description = __( 'This visit was flagged because the affiliate conversion rate was outside of the defined limits.', 'affiliatewp-fraud-prevention' );
				break;

			default:
				$description = $flag;
				break;
		}

		return $description;
	}
}
