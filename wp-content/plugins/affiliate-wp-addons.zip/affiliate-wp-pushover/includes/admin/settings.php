<?php

class AffiliateWP_Pushover_Admin {

	public function __construct() {
		add_filter( 'affwp_settings_tabs', array( $this, 'setting_tab' ) );
		add_filter( 'affwp_settings', array( $this, 'register_settings' ) );
	}

	public function setting_tab( $tabs ) {
		$tabs['pushover'] = __( 'Pushover', 'affiliate-wp-pushover' );
		return $tabs;
	}

	// TODO: Add docblock.
	public function register_settings( array $settings ) : array {

		$settings['pushover'] = array(
			'pushover_app_key' => array(
				'name' => __( 'Pushover Application Key', 'affiliate-wp-pushover' ),
				'desc' => '',
				'type' => '',
				'callback' => array( $this, 'pushover' ),
			),
		);

		return $settings;
	}

	public function pushover() {
		$settings = get_option( 'affwp_settings' );
		$pushover_app_key = isset( $settings['pushover_app_key'] ) ? $settings['pushover_app_key'] : '';
?>
		<form id="affiliatewp-pushover-form">
			<input type="text" size="50" name="affwp_settings[pushover_app_key]" value="<?php echo $pushover_app_key; ?>" placeholder="Enter Application Key" />
		</form>
<?php
	}

}

new AffiliateWP_Pushover_Admin;
